# RigLogix Web Application

Direct-to-Owner Heavy Machinery Aggregator & Logistics Web Application built with React, Vite, TypeScript, and Tailwind CSS.

## Features
- **Direct-to-Owner Fleet Hub**: CAT excavators, Bauer rotary drilling rigs, Liebherr all-terrain cranes, and Kenworth heavy dump trucks with transparent 3.5% fee vs 30% broker cut.
- **Reverse Auction Bidding Matrix**: Live contractor counter-bidding, savings tracker, and instant Escrow Lock.
- **Spatial Hex Radar**: Interactive radar simulation with H3 resolution 8 hex sectors, distance calculations, and J1939 CAN-bus telematics (fuel level, engine hours, GPS coordinates).
- **Rental Booking Engine**: Schedule date chips, work shifts, duration slider, transparent price breakdown, and milestone stepper tracker.
- **5-Star Owner Reviews**: Star rating, feedback tags, and comment submission.

## Running Locally / In Web Applet
```bash
cd web
npm install
npm run dev
```

The web application runs on port 3000 (`http://localhost:3000`).
