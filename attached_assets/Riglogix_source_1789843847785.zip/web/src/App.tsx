import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { MachineryCatalog } from './components/MachineryCatalog';
import { ReverseAuction } from './components/ReverseAuction';
import { SpatialRadar } from './components/SpatialRadar';
import { RentalBookingModal } from './components/RentalBookingModal';
import { LiveTrackerModal } from './components/LiveTrackerModal';
import { SpecsExplainerModal } from './components/SpecsExplainerModal';
import { initialMachinery, initialJobs, initialBookings } from './data/mockData';
import { Machinery, JobListing, RentalBooking } from './types';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'auction' | 'radar'>('catalog');
  const [machineryList, setMachineryList] = useState<Machinery[]>(initialMachinery);
  const [jobs, setJobs] = useState<JobListing[]>(initialJobs);
  const [bookings, setBookings] = useState<RentalBooking[]>(initialBookings);

  // Modals state
  const [bookingMachine, setBookingMachine] = useState<Machinery | null>(null);
  const [exploringMachine, setExploringMachine] = useState<Machinery | null>(null);
  const [activeTrackingBooking, setActiveTrackingBooking] = useState<RentalBooking | null>(null);
  const [showBookingsDrawer, setShowBookingsDrawer] = useState<boolean>(false);

  // Auction Actions
  const handleAwardJob = (jobId: number) => {
    setJobs(jobs.map(j => (j.id === jobId ? { ...j, isEscrowLocked: true } : j)));
  };

  const handleSubmitBid = (jobId: number, bidAmount: number, bidderName: string) => {
    setJobs(jobs.map(j => {
      if (j.id === jobId) {
        return {
          ...j,
          lowestBidAmount: bidAmount,
          lowestBidderName: bidderName,
          totalBids: j.totalBids + 1
        };
      }
      return j;
    }));
  };

  // Booking Actions
  const handleConfirmBooking = (bookingData: Partial<RentalBooking>) => {
    const newBooking: RentalBooking = {
      id: Date.now() % 100000,
      machineryId: bookingData.machineryId || 1,
      machineryTitle: bookingData.machineryTitle || '',
      ownerName: bookingData.ownerName || '',
      status: 'PENDING',
      scheduledDate: bookingData.scheduledDate || 'Today, Sep 19',
      scheduledTime: bookingData.scheduledTime || '08:00 AM - 04:00 PM',
      jobLocation: bookingData.jobLocation || 'Jobsite Alpha',
      unitsRequested: bookingData.unitsRequested || 8,
      totalAmount: bookingData.totalAmount || 1000,
      platformFee: bookingData.platformFee || 35,
      ownerEarnings: bookingData.ownerEarnings || 965,
      traditionalSavings: bookingData.traditionalSavings || 265,
      telematicsLat: bookingData.telematicsLat || 37.7749,
      telematicsLng: bookingData.telematicsLng || -122.4194,
      createdAt: bookingData.createdAt || new Date().toISOString()
    };

    setBookings([newBooking, ...bookings]);
    setBookingMachine(null);
    setActiveTrackingBooking(newBooking);
  };

  const handleAdvanceStatus = (bookingId: number) => {
    const statusOrder: Array<'PENDING' | 'MOBILIZING' | 'IN_PROGRESS' | 'COMPLETED'> = [
      'PENDING',
      'MOBILIZING',
      'IN_PROGRESS',
      'COMPLETED'
    ];

    setBookings(bookings.map(b => {
      if (b.id === bookingId) {
        const nextIdx = Math.min(statusOrder.indexOf(b.status) + 1, statusOrder.length - 1);
        const updated = { ...b, status: statusOrder[nextIdx] };
        if (activeTrackingBooking?.id === bookingId) {
          setActiveTrackingBooking(updated);
        }
        return updated;
      }
      return b;
    }));
  };

  const handleSubmitReview = (bookingId: number, rating: number, comment: string, tags: string[]) => {
    setBookings(bookings.map(b => {
      if (b.id === bookingId) {
        const updated = { ...b, rating, reviewComment: comment, reviewTags: tags };
        if (activeTrackingBooking?.id === bookingId) {
          setActiveTrackingBooking(updated);
        }
        return updated;
      }
      return b;
    }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeBookingsCount={bookings.filter(b => b.status !== 'COMPLETED').length}
        onOpenBookings={() => setShowBookingsDrawer(true)}
      />

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'catalog' && (
          <MachineryCatalog
            machineryList={machineryList}
            onBookNow={(machine) => setBookingMachine(machine)}
            onExploreStructure={(machine) => setExploringMachine(machine)}
          />
        )}

        {activeTab === 'auction' && (
          <ReverseAuction
            jobs={jobs}
            onAwardJob={handleAwardJob}
            onSubmitBid={handleSubmitBid}
          />
        )}

        {activeTab === 'radar' && (
          <SpatialRadar
            machineryList={machineryList}
            onSelectMachine={(machine) => setBookingMachine(machine)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-850 bg-slate-900/60 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>RigLogix Commercial Machinery Network • Direct-to-Owner Smart Dispatch</span>
          <span className="font-mono text-cyan-400">Platform Fee: 3.5% vs Legacy Broker 30%</span>
        </div>
      </footer>

      {/* Booking Modal */}
      {bookingMachine && (
        <RentalBookingModal
          machinery={bookingMachine}
          onClose={() => setBookingMachine(null)}
          onConfirmBooking={handleConfirmBooking}
        />
      )}

      {/* Specs Guide Modal */}
      {exploringMachine && (
        <SpecsExplainerModal
          machinery={exploringMachine}
          onClose={() => setExploringMachine(null)}
          onBookNow={(machine) => {
            setExploringMachine(null);
            setBookingMachine(machine);
          }}
        />
      )}

      {/* Active Live Tracking Modal */}
      {activeTrackingBooking && (
        <LiveTrackerModal
          booking={activeTrackingBooking}
          onClose={() => setActiveTrackingBooking(null)}
          onAdvanceStatus={handleAdvanceStatus}
          onSubmitReview={handleSubmitReview}
        />
      )}

      {/* Bookings Drawer / List */}
      {showBookingsDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex justify-end">
          <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full p-6 space-y-4 overflow-y-auto flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-lg font-bold text-white">Your Rental Deployments</h3>
                <button
                  onClick={() => setShowBookingsDrawer(false)}
                  className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800"
                >
                  Close
                </button>
              </div>

              {bookings.length === 0 ? (
                <p className="text-xs text-slate-400">No equipment bookings yet.</p>
              ) : (
                <div className="space-y-3">
                  {bookings.map((b) => (
                    <div
                      key={b.id}
                      onClick={() => {
                        setActiveTrackingBooking(b);
                        setShowBookingsDrawer(false);
                      }}
                      className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 cursor-pointer space-y-1 transition-all"
                    >
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="font-mono text-amber-400">#{b.id}</span>
                        <span className="px-2 py-0.5 rounded font-bold uppercase bg-slate-800 text-cyan-400">
                          {b.status.replace('_', ' ')}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white truncate">{b.machineryTitle}</h4>
                      <p className="text-xs text-slate-400">{b.scheduledDate} • {b.jobLocation}</p>
                      <div className="flex justify-between items-center pt-1 text-xs">
                        <span className="text-slate-500">Escrow</span>
                        <span className="font-bold text-emerald-400">${b.totalAmount.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
