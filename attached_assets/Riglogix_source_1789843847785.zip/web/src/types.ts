export interface Machinery {
  id: number;
  title: string;
  category: string; // 'EARTHMOVING' | 'FOUNDATION' | 'CRANE' | 'HAULAGE'
  subCategory: string; // 'Excavator' | 'Rotary Drilling Rig' | 'Crane' | 'Dump Truck'
  tonnage: string;
  operatorIncluded: boolean;
  baseRateHourly: number;
  transparentPlatformFee: number;
  traditionalBrokerCost: number;
  h3HexId: string;
  latitude: number;
  longitude: number;
  distanceKm: number;
  ownerName: string;
  ownerRating: number;
  verifiedOwner: boolean;
  imageUrl: string;
  engineSpecs: string;
  plainEnglishGuide: string;
  primaryApplication: string;
  telematicsFuelPct: number;
  telematicsEngineHours: number;
}

export interface JobListing {
  id: number;
  title: string;
  location: string;
  category: string;
  targetBudget: number;
  lowestBidAmount: number;
  lowestBidderName: string;
  totalBids: number;
  expiresInMinutes: number;
  scopeDescription: string;
  isEscrowLocked: boolean;
}

export interface RentalBooking {
  id: number;
  machineryId: number;
  machineryTitle: string;
  ownerName: string;
  status: 'PENDING' | 'MOBILIZING' | 'IN_PROGRESS' | 'COMPLETED';
  scheduledDate: string;
  scheduledTime: string;
  jobLocation: string;
  unitsRequested: number;
  totalAmount: number;
  platformFee: number;
  ownerEarnings: number;
  traditionalSavings: number;
  telematicsLat: number;
  telematicsLng: number;
  rating?: number;
  reviewComment?: string;
  reviewTags?: string[];
  createdAt: string;
}
