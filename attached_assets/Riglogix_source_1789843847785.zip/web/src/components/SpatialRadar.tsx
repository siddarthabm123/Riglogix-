import React, { useState } from 'react';
import { Machinery } from '../types';
import { Radio, Gauge, MapPin, Fuel, ShieldCheck, Compass } from 'lucide-react';

interface SpatialRadarProps {
  machineryList: Machinery[];
  onSelectMachine: (machine: Machinery) => void;
}

export const SpatialRadar: React.FC<SpatialRadarProps> = ({
  machineryList,
  onSelectMachine
}) => {
  const [activeRadarNode, setActiveRadarNode] = useState<Machinery>(machineryList[0]);
  const [geofenceKm, setGeofenceKm] = useState<number>(25);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-slate-900 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
              <span>Uber-H3 Hexagonal Spatial Indexing</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              Real-Time Telematics & Fleet Proximity
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              High-resolution spatial tracking maps idle and mobilized equipment across Bay Area hex sectors with CAN-bus sensor telemetry.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-right">
            <span className="text-[10px] text-slate-400 block uppercase tracking-wider">Geofence Range</span>
            <div className="flex items-center space-x-2">
              <input
                type="range"
                min="5"
                max="50"
                value={geofenceKm}
                onChange={(e) => setGeofenceKm(Number(e.target.value))}
                className="accent-cyan-500 cursor-pointer w-28"
              />
              <span className="text-sm font-bold font-mono text-cyan-400">{geofenceKm} km</span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Radar Visual Canvas + Equipment Node Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Radar Graphic View */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center relative min-h-[420px] overflow-hidden">
          {/* Concentric Radar Rings */}
          <div className="absolute w-80 h-80 sm:w-96 sm:h-96 rounded-full border border-cyan-500/20 animate-ping opacity-25 pointer-events-none" />
          <div className="absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full border border-cyan-500/30 pointer-events-none" />
          <div className="absolute w-52 h-52 sm:w-60 sm:h-60 rounded-full border border-cyan-500/20 border-dashed pointer-events-none" />
          <div className="absolute w-32 h-32 rounded-full border border-cyan-500/40 pointer-events-none" />

          {/* Crosshairs */}
          <div className="absolute w-full h-[1px] bg-cyan-500/20 pointer-events-none" />
          <div className="absolute h-full w-[1px] bg-cyan-500/20 pointer-events-none" />

          {/* Center Origin (Jobsite) */}
          <div className="z-10 flex flex-col items-center space-y-1">
            <div className="w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/50">
              <MapPin className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-amber-400 font-mono bg-slate-950/80 px-2 py-0.5 rounded border border-amber-500/30">
              Jobsite Origin
            </span>
          </div>

          {/* Placed Nodes on the Radar */}
          {machineryList.map((m, index) => {
            const angle = (index * (360 / machineryList.length)) * (Math.PI / 180);
            const radius = 60 + index * 30; // spread outwards
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            const isSelected = activeRadarNode.id === m.id;

            return (
              <button
                key={m.id}
                onClick={() => setActiveRadarNode(m)}
                style={{
                  transform: `translate(${x}px, ${y}px)`
                }}
                className={`absolute z-20 transition-all group p-1.5 rounded-full flex items-center justify-center ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 scale-125 shadow-lg shadow-cyan-500/50 ring-4 ring-cyan-500/30'
                    : 'bg-slate-800 text-cyan-400 hover:bg-cyan-900 border border-cyan-500/40'
                }`}
                title={m.title}
              >
                <span className="text-[10px] font-bold font-mono px-1">#{m.id}</span>
              </button>
            );
          })}

          <div className="absolute bottom-3 left-4 text-[11px] text-slate-500 font-mono">
            Scanning H3 Resolution 8 • 4 Target Nodes Active
          </div>
        </div>

        {/* Selected Telematics Details Panel */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-wider block">
                  H3 Hex Sector: #{activeRadarNode.h3HexId}
                </span>
                <h3 className="text-xl font-bold text-white leading-tight">{activeRadarNode.title}</h3>
                <p className="text-xs text-slate-400">{activeRadarNode.ownerName}</p>
              </div>
              <div className="px-3 py-1 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-300 text-xs font-bold font-mono">
                {activeRadarNode.distanceKm} km away
              </div>
            </div>

            <img
              src={activeRadarNode.imageUrl}
              alt={activeRadarNode.title}
              className="w-full h-36 object-cover rounded-xl border border-slate-800"
            />

            {/* Telematics CAN-Bus Gauges */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <div className="flex items-center space-x-1.5 text-xs text-slate-400">
                  <Fuel className="w-3.5 h-3.5 text-amber-400" />
                  <span>Fuel Tank Level</span>
                </div>
                <div className="text-lg font-mono font-extrabold text-white">
                  {activeRadarNode.telematicsFuelPct}%
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full"
                    style={{ width: `${activeRadarNode.telematicsFuelPct}%` }}
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <div className="flex items-center space-x-1.5 text-xs text-slate-400">
                  <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Engine Hours</span>
                </div>
                <div className="text-lg font-mono font-extrabold text-white">
                  {activeRadarNode.telematicsEngineHours} hrs
                </div>
                <span className="text-[10px] text-emerald-400">Service Status: Optimal</span>
              </div>
            </div>

            {/* GPS Coordinate Display */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono text-slate-400 flex justify-between">
              <span>Lat: {activeRadarNode.latitude.toFixed(4)}</span>
              <span>Lng: {activeRadarNode.longitude.toFixed(4)}</span>
              <span className="text-cyan-400">Can-Bus 2.0B</span>
            </div>
          </div>

          <button
            onClick={() => onSelectMachine(activeRadarNode)}
            className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors shadow-lg shadow-amber-500/20"
          >
            Direct Mobilize & Rent #{activeRadarNode.id}
          </button>
        </div>
      </div>
    </div>
  );
};
