import React, { useState } from 'react';
import { RentalBooking } from '../types';
import { X, CheckCircle, Clock, Truck, ShieldAlert, Star, Send } from 'lucide-react';

interface LiveTrackerModalProps {
  booking: RentalBooking;
  onClose: () => void;
  onAdvanceStatus: (bookingId: number) => void;
  onSubmitReview: (bookingId: number, rating: number, comment: string, tags: string[]) => void;
}

export const LiveTrackerModal: React.FC<LiveTrackerModalProps> = ({
  booking,
  onClose,
  onAdvanceStatus,
  onSubmitReview
}) => {
  const [rating, setRating] = useState<number>(booking.rating || 5);
  const [comment, setComment] = useState<string>(booking.reviewComment || '');
  const [selectedTags, setSelectedTags] = useState<string[]>(
    booking.reviewTags || ['On-Time Dispatch', 'Clean Cab', 'Skilled Operator']
  );
  const [reviewSubmitted, setReviewSubmitted] = useState<boolean>(!!booking.rating);

  const milestones = [
    { key: 'PENDING', label: 'Order Placed & Escrow Locked' },
    { key: 'MOBILIZING', label: 'Mobilizing on Lowboy Transport' },
    { key: 'IN_PROGRESS', label: 'Active on Jobsite' },
    { key: 'COMPLETED', label: 'Shift Complete & Demobilized' }
  ];

  const currentIdx = milestones.findIndex(m => m.key === booking.status);

  const availableTags = [
    'On-Time Dispatch',
    'Clean Cab',
    'Skilled Operator',
    'Transparent Pricing',
    'Pristine Hydraulics'
  ];

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleReviewSubmit = () => {
    onSubmitReview(booking.id, rating, comment, selectedTags);
    setReviewSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 space-y-6 overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                BOOKING #{booking.id}
              </span>
              <span className="text-xs text-slate-400">{booking.scheduledDate}</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">{booking.machineryTitle}</h2>
            <p className="text-xs text-slate-400">Owner: {booking.ownerName}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Milestone Tracker Stepper */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Real-Time Mobilization Progress
          </h3>

          <div className="space-y-3">
            {milestones.map((m, idx) => {
              const isPast = idx < currentIdx;
              const isCurrent = idx === currentIdx;

              return (
                <div key={m.key} className="flex items-center space-x-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
                      isPast
                        ? 'bg-emerald-500 text-slate-950'
                        : isCurrent
                        ? 'bg-amber-500 text-slate-950 ring-4 ring-amber-500/30'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {isPast ? <CheckCircle className="w-4 h-4" /> : idx + 1}
                  </div>
                  <div className="flex-1">
                    <p
                      className={`text-xs font-semibold ${
                        isCurrent ? 'text-amber-400' : isPast ? 'text-white' : 'text-slate-500'
                      }`}
                    >
                      {m.label}
                    </p>
                  </div>
                  {isCurrent && (
                    <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded animate-pulse">
                      LIVE
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {booking.status !== 'COMPLETED' && (
            <button
              onClick={() => onAdvanceStatus(booking.id)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 border border-slate-700 transition-colors"
            >
              Advance Milestone Next Phase →
            </button>
          )}
        </div>

        {/* Telematics & Shift Details */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-400">Site Location:</span>
            <span className="text-white font-medium">{booking.jobLocation}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Time Shift:</span>
            <span className="text-white font-medium">{booking.scheduledTime}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Escrow Total:</span>
            <span className="text-amber-400 font-bold">${booking.totalAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Verified GPS Coordinates:</span>
            <span className="text-cyan-400 font-mono">{booking.telematicsLat.toFixed(4)}, {booking.telematicsLng.toFixed(4)}</span>
          </div>
        </div>

        {/* 5-Star Owner Review Section */}
        <div className="border-t border-slate-800 pt-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>Verified Owner Rating & Feedback</span>
          </h3>

          {!reviewSubmitted ? (
            <div className="space-y-3">
              {/* Star Selector */}
              <div className="flex items-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-1 text-amber-400 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-6 h-6 ${star <= rating ? 'fill-amber-400' : 'text-slate-600'}`}
                    />
                  </button>
                ))}
                <span className="text-xs font-semibold text-amber-400 ml-2">
                  {rating === 5 ? 'Exceptional 5/5' : `${rating}/5 Stars`}
                </span>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5">
                {availableTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                      selectedTags.includes(tag)
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-950 text-slate-400 border border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Comment Input */}
              <textarea
                rows={2}
                placeholder="Share operator punctuality, equipment maintenance, hydraulic performance..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />

              <button
                onClick={handleReviewSubmit}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 transition-colors flex items-center justify-center space-x-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Verified Review</span>
              </button>
            </div>
          ) : (
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <div className="flex items-center space-x-1 text-amber-400">
                {[...Array(rating)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                ))}
                <span className="text-xs font-bold text-white ml-2">Verified Feedback Submitted</span>
              </div>
              <p className="text-xs text-slate-400 italic">"{comment}"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
