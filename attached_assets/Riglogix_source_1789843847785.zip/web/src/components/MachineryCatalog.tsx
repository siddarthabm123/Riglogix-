import React, { useState } from 'react';
import { Machinery } from '../types';
import { CheckCircle, Info, Star, Zap, Gauge, MapPin, Search } from 'lucide-react';

interface MachineryCatalogProps {
  machineryList: Machinery[];
  onBookNow: (machine: Machinery) => void;
  onExploreStructure: (machine: Machinery) => void;
}

export const MachineryCatalog: React.FC<MachineryCatalogProps> = ({
  machineryList,
  onBookNow,
  onExploreStructure
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = machineryList.filter(item => {
    const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.subCategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.ownerName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Hero Banner: Zero Broker Margins & Direct-to-Owner */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-cyan-500/10 border border-slate-800 p-6 sm:p-8">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <Zap className="w-3.5 h-3.5" />
            <span>Disrupting 30% Legacy Broker Markup</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Direct-to-Owner Heavy Equipment Fleet
          </h1>
          <p className="text-sm sm:text-base text-slate-400">
            Book certified excavators, rotary drilling rigs, all-terrain cranes, and haulage dump trucks with GPS verified telematics and transparent 3.5% platform fees.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900/50 p-4 rounded-xl border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search equipment, specs, owner..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          {['ALL', 'EARTHMOVING', 'FOUNDATION', 'CRANE', 'HAULAGE'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Equipment Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="group rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden hover:border-slate-700 transition-all flex flex-col"
          >
            {/* Image Preview with Badge */}
            <div className="relative h-48 sm:h-56 overflow-hidden bg-slate-950">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80" />

              <div className="absolute top-3 left-3 flex gap-2">
                <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-slate-950/80 text-white backdrop-blur-md border border-slate-700">
                  {item.subCategory}
                </span>
                {item.verifiedOwner && (
                  <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-bold bg-cyan-950/80 text-cyan-300 backdrop-blur-md border border-cyan-700">
                    <CheckCircle className="w-3 h-3" />
                    <span>Verified Owner</span>
                  </span>
                )}
              </div>

              <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                <div>
                  <div className="text-xs text-amber-400 font-semibold tracking-wide uppercase">
                    {item.tonnage}
                  </div>
                  <h3 className="text-lg font-bold text-white leading-snug">{item.title}</h3>
                </div>
                <div className="text-right bg-slate-950/80 px-2.5 py-1.5 rounded-lg border border-slate-800 backdrop-blur-sm">
                  <div className="text-lg font-extrabold text-amber-400">${item.baseRateHourly}</div>
                  <div className="text-[10px] text-slate-400">/ hour rate</div>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                {/* Engine Specs */}
                <div className="flex items-center space-x-2 text-xs text-slate-300 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80">
                  <Gauge className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="truncate">{item.engineSpecs}</span>
                </div>

                {/* Plain English Guide */}
                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                  {item.plainEnglishGuide}
                </p>

                {/* Transparent Pricing vs Traditional Broker */}
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Platform Fee (3.5%)</span>
                    <span className="font-semibold text-cyan-400">+${item.transparentPlatformFee}/hr</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 block text-[10px]">Legacy Broker Saved</span>
                    <span className="font-semibold text-emerald-400 line-through">-${item.traditionalBrokerCost}/hr</span>
                  </div>
                </div>

                {/* Owner & Telematics Info */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <div className="flex items-center space-x-1.5">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span className="font-semibold text-white">{item.ownerRating}</span>
                    <span>• {item.ownerName}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-slate-400">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>{item.distanceKm} km away</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => onExploreStructure(item)}
                  className="flex items-center justify-center space-x-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Specs Guide</span>
                </button>

                <button
                  onClick={() => onBookNow(item)}
                  className="flex items-center justify-center space-x-1.5 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 transition-colors shadow-lg shadow-amber-500/20"
                >
                  <span>Book Equipment</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
