import React from 'react';
import { Machinery } from '../types';
import { X, CheckCircle, Gauge, Cpu, Wrench, ShieldCheck } from 'lucide-react';

interface SpecsExplainerModalProps {
  machinery: Machinery;
  onClose: () => void;
  onBookNow: (machine: Machinery) => void;
}

export const SpecsExplainerModal: React.FC<SpecsExplainerModalProps> = ({
  machinery,
  onClose,
  onBookNow
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-6 overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 uppercase">
                {machinery.subCategory}
              </span>
              <span className="text-xs text-slate-400 font-mono">Tonnage: {machinery.tonnage}</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-1">{machinery.title}</h2>
            <p className="text-xs text-slate-400">Owner: {machinery.ownerName}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hero Image */}
        <img
          src={machinery.imageUrl}
          alt={machinery.title}
          className="w-full h-56 object-cover rounded-xl border border-slate-800"
        />

        {/* Plain English Guide */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
          <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-1.5">
            <Wrench className="w-4 h-4" />
            <span>Plain English Anatomy & Purpose</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            {machinery.plainEnglishGuide}
          </p>
        </div>

        {/* Key Operational Applications */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Primary Application & Technical Specifications
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-500 block text-[10px] uppercase">Engine & Power Output</span>
              <span className="font-semibold text-white">{machinery.engineSpecs}</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-500 block text-[10px] uppercase">Primary Jobsite Role</span>
              <span className="font-semibold text-cyan-400">{machinery.primaryApplication}</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-500 block text-[10px] uppercase">Operator Qualification</span>
              <span className="font-semibold text-emerald-400">
                {machinery.operatorIncluded ? 'Certified Union Operator Included' : 'Bare Rental Available'}
              </span>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-500 block text-[10px] uppercase">Telemetry Protocol</span>
              <span className="font-semibold text-amber-400">J1939 CAN-Bus 2.0B / H3 Hex</span>
            </div>
          </div>
        </div>

        {/* Direct Booking CTA */}
        <div className="flex gap-3 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors"
          >
            Close Guide
          </button>
          <button
            onClick={() => {
              onClose();
              onBookNow(machinery);
            }}
            className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 transition-colors shadow-lg shadow-amber-500/20"
          >
            Proceed to Booking
          </button>
        </div>
      </div>
    </div>
  );
};
