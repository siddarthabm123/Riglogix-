import React, { useState } from 'react';
import { JobListing } from '../types';
import { Gavel, Clock, Lock, TrendingDown, DollarSign, ShieldAlert } from 'lucide-react';

interface ReverseAuctionProps {
  jobs: JobListing[];
  onAwardJob: (jobId: number) => void;
  onSubmitBid: (jobId: number, bidAmount: number, bidderName: string) => void;
}

export const ReverseAuction: React.FC<ReverseAuctionProps> = ({
  jobs,
  onAwardJob,
  onSubmitBid
}) => {
  const [biddingJobId, setBiddingJobId] = useState<number | null>(null);
  const [bidAmount, setBidAmount] = useState<string>('');
  const [bidderName, setBidderName] = useState<string>('NorCal Rigging & Logistics');

  const handlePlaceBid = (job: JobListing) => {
    const val = parseFloat(bidAmount);
    if (!val || val >= job.lowestBidAmount) {
      alert(`Bid must be lower than current lowest bid of $${job.lowestBidAmount.toLocaleString()}`);
      return;
    }
    onSubmitBid(job.id, val, bidderName);
    setBiddingJobId(null);
    setBidAmount('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-amber-950/40 border border-slate-800 p-6 sm:p-8">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Competitive Reverse-Auction Engine</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Live Commercial Project Bidding
          </h1>
          <p className="text-sm sm:text-base text-slate-400">
            Contractors compete downward in real time. General contractors lock escrow with direct owner-operators, eliminating multi-layer broker margins.
          </p>
        </div>
      </div>

      {/* Active Auction Cards */}
      <div className="grid grid-cols-1 gap-6">
        {jobs.map((job) => {
          const savingsAmount = job.targetBudget - job.lowestBidAmount;
          const savingsPct = ((savingsAmount / job.targetBudget) * 100).toFixed(1);

          return (
            <div
              key={job.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 hover:border-slate-700 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-amber-500/20 text-amber-300 uppercase tracking-wider">
                      {job.category}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">ID #{job.id}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white">{job.title}</h3>
                  <p className="text-xs text-slate-400">{job.location}</p>
                </div>

                <div className="flex items-center space-x-3 sm:space-x-4">
                  <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-amber-400">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>{job.expiresInMinutes}m remaining</span>
                  </div>
                  {job.isEscrowLocked && (
                    <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-700/60 text-xs font-bold text-emerald-300">
                      <Lock className="w-3.5 h-3.5" />
                      <span>Escrow Secured</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Scope */}
              <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                {job.scopeDescription}
              </p>

              {/* Bid Metrics Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Owner Target</span>
                  <span className="text-lg font-bold text-slate-300">${job.targetBudget.toLocaleString()}</span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Lowest Bid</span>
                  <span className="text-lg font-extrabold text-amber-400">${job.lowestBidAmount.toLocaleString()}</span>
                  <span className="text-[10px] text-slate-400 block truncate">{job.lowestBidderName}</span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Savings Generated</span>
                  <span className="text-lg font-bold text-emerald-400">
                    -${savingsAmount.toLocaleString()} ({savingsPct}%)
                  </span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Bids Placed</span>
                  <span className="text-lg font-bold text-cyan-400">{job.totalBids} Competitors</span>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                {!job.isEscrowLocked ? (
                  <>
                    <button
                      onClick={() => setBiddingJobId(job.id)}
                      className="flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-semibold text-white border border-slate-700 transition-colors"
                    >
                      <DollarSign className="w-4 h-4 text-amber-400" />
                      <span>Submit Lower Counter-Bid</span>
                    </button>

                    <button
                      onClick={() => onAwardJob(job.id)}
                      className="flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-sm font-bold text-slate-950 transition-colors shadow-lg shadow-amber-500/20"
                    >
                      <Gavel className="w-4 h-4" />
                      <span>Award Job & Lock Escrow</span>
                    </button>
                  </>
                ) : (
                  <div className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-emerald-950/40 border border-emerald-800 text-sm font-bold text-emerald-400">
                    <Lock className="w-4 h-4" />
                    <span>Project Awarded to {job.lowestBidderName} • Escrow Deposited</span>
                  </div>
                )}
              </div>

              {/* Bid Modal / Inline Form */}
              {biddingJobId === job.id && (
                <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/50 space-y-3 mt-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-amber-400">Place Counter Bid for Job #{job.id}</h4>
                    <span className="text-xs text-slate-400">Must be under ${job.lowestBidAmount.toLocaleString()}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Contractor / Operator Name</label>
                      <input
                        type="text"
                        value={bidderName}
                        onChange={(e) => setBidderName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Your Bid Amount ($)</label>
                      <input
                        type="number"
                        placeholder={`e.g. ${job.lowestBidAmount - 500}`}
                        value={bidAmount}
                        onChange={(e) => setBidAmount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-1">
                    <button
                      onClick={() => setBiddingJobId(null)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handlePlaceBid(job)}
                      className="px-4 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950"
                    >
                      Confirm Bid Submission
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
