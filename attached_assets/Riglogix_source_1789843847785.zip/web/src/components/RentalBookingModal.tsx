import React, { useState } from 'react';
import { Machinery, RentalBooking } from '../types';
import { X, Calendar, Clock, MapPin, CheckCircle, ShieldCheck } from 'lucide-react';

interface RentalBookingModalProps {
  machinery: Machinery;
  onClose: () => void;
  onConfirmBooking: (booking: Partial<RentalBooking>) => void;
}

export const RentalBookingModal: React.FC<RentalBookingModalProps> = ({
  machinery,
  onClose,
  onConfirmBooking
}) => {
  const [dateOption, setDateOption] = useState<'Today' | 'Tomorrow' | 'Next Monday'>('Today');
  const [shiftTime, setShiftTime] = useState<'08:00 AM - 04:00 PM' | '06:00 AM - 02:00 PM' | 'Full Day (24h)'>('08:00 AM - 04:00 PM');
  const [location, setLocation] = useState<string>('San Francisco Peninsula Jobsite Hex #8828308281ff');
  const [units, setUnits] = useState<number>(8);

  const subtotal = machinery.baseRateHourly * units;
  const platformFee = Number((subtotal * 0.035).toFixed(2));
  const totalCost = Number((subtotal + platformFee).toFixed(2));
  const legacyBrokerCost = Number((subtotal * 0.30).toFixed(2));
  const contractorSavings = Number((legacyBrokerCost - platformFee).toFixed(2));

  const handleConfirm = () => {
    onConfirmBooking({
      machineryId: machinery.id,
      machineryTitle: machinery.title,
      ownerName: machinery.ownerName,
      status: 'PENDING',
      scheduledDate: `${dateOption}, Sep 2026`,
      scheduledTime: shiftTime,
      jobLocation: location,
      unitsRequested: units,
      totalAmount: totalCost,
      platformFee: platformFee,
      ownerEarnings: subtotal,
      traditionalSavings: contractorSavings,
      telematicsLat: machinery.latitude,
      telematicsLng: machinery.longitude,
      createdAt: new Date().toISOString().substring(0, 16).replace('T', ' ')
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 space-y-6 overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 uppercase">
                {machinery.subCategory}
              </span>
              <span className="text-xs text-slate-400 font-mono">Owner: {machinery.ownerName}</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">{machinery.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Date Selector */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
            <Calendar className="w-4 h-4 text-amber-400" />
            <span>Deployment Schedule</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['Today', 'Tomorrow', 'Next Monday'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDateOption(d)}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all border ${
                  dateOption === d
                    ? 'bg-amber-500 text-slate-950 border-amber-500 shadow'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Time Shift */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>Work Shift Window</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {(['08:00 AM - 04:00 PM', '06:00 AM - 02:00 PM', 'Full Day (24h)'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setShiftTime(t)}
                className={`py-2 px-2.5 rounded-lg text-xs font-semibold transition-all border text-center ${
                  shiftTime === t
                    ? 'bg-cyan-500 text-slate-950 border-cyan-500 shadow'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Job Location */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>Delivery / Site Location</span>
          </label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Hours / Units Selector */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-300">Duration (Operating Hours)</span>
            <span className="font-mono text-amber-400 font-bold">{units} hours</span>
          </div>
          <input
            type="range"
            min="4"
            max="40"
            step="2"
            value={units}
            onChange={(e) => setUnits(Number(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        {/* Transparent Cost Breakdown */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>Base Owner Rate ({units}h × ${machinery.baseRateHourly}/h)</span>
            <span className="font-mono text-white">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Transparent Platform Fee (3.5%)</span>
            <span className="font-mono text-cyan-400">+${platformFee.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-emerald-400 border-t border-slate-800/80 pt-2">
            <span>Legacy Broker Cut Saved</span>
            <span className="font-mono line-through">-${contractorSavings.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-base font-extrabold text-white border-t border-slate-800 pt-2">
            <span>Total Escrow Deposit</span>
            <span className="font-mono text-amber-400">${totalCost.toFixed(2)}</span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex gap-3 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            className="flex-2 py-3 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 transition-colors shadow-lg shadow-amber-500/20 flex items-center justify-center space-x-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Confirm & Lock Escrow</span>
          </button>
        </div>
      </div>
    </div>
  );
};
