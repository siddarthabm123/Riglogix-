/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        industrialAmber: '#F59E0B',
        highTechCyan: '#06B6D4',
        hexagonBlue: '#3B82F6',
        darkSlate: {
          900: '#0F172A',
          800: '#1E293B',
          700: '#334155',
          600: '#475569',
        }
      }
    },
  },
  plugins: [],
}
