package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.PrepopulatedData
import com.example.data.repository.AntigravityRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var database: AppDatabase
  private lateinit var repository: AntigravityRepository

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repository = AntigravityRepository(database)
  }

  @After
  fun teardown() {
    database.close()
  }

  @Test
  fun `read app name from strings`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("RigLogix", appName)
  }

  @Test
  fun `verify room database seeding and direct booking transparent math`() = runBlocking {
    AppDatabase.populateDatabase(database)

    val machineryList = repository.allMachinery.first()
    assertTrue(machineryList.isNotEmpty())

    val borewellRig = machineryList.first { it.subCategory == "Borewell Rig" }
    assertNotNull(borewellRig)

    // Verify Direct Booking pricing calculation (3.5% fee vs 30% broker cut)
    val depthFeet = 1000.0
    val bookingId = repository.createBooking(
      machinery = borewellRig,
      jobLocation = "Farm Sector Hex #8828308281ff",
      jobUnits = depthFeet
    )
    assertTrue(bookingId > 0)

    val bookings = repository.allBookings.first()
    val confirmedBooking = bookings.first { it.id == bookingId.toInt() }

    val expectedSubtotal = borewellRig.baseRate + (borewellRig.ratePerUnit * depthFeet) + borewellRig.fuelIndexSurcharge
    val expectedAntigravityFee = expectedSubtotal * 0.035
    val expectedTotalCost = expectedSubtotal + expectedAntigravityFee

    assertEquals(expectedSubtotal, confirmedBooking.ownerNetEarnings, 0.01)
    assertEquals(expectedAntigravityFee, confirmedBooking.antigravityFee, 0.01)
    assertEquals(expectedTotalCost, confirmedBooking.totalCustomerCost, 0.01)
  }

  @Test
  fun `verify reverse auction downward bidding flow`() = runBlocking {
    AppDatabase.populateDatabase(database)

    val jobId = repository.createAuctionJob(
      title = "Drill 800ft Commercial Borewell",
      category = "Agriculture",
      location = "Central Orchard Hex #8828308281ff",
      details = "High pressure air rig needed",
      ceilingPrice = 14000.0
    )

    // Operator 1 bids $13,200
    repository.submitBid(
      jobId = jobId.toInt(),
      operatorName = "Apex Drilling Fleet",
      operatorPhone = "+15551234",
      operatorRating = 4.9,
      equipmentTitle = "Atlas Copco Rig",
      bidAmount = 13200.0,
      etaMinutes = 45,
      h3DistanceKm = 12.0
    )

    // Operator 2 bids lower ($12,500)
    repository.submitBid(
      jobId = jobId.toInt(),
      operatorName = "Deccan High Pressure Rigs",
      operatorPhone = "+15555678",
      operatorRating = 4.95,
      equipmentTitle = "PRD Super Heavy Rig",
      bidAmount = 12500.0,
      etaMinutes = 30,
      h3DistanceKm = 8.5
    )

    val bids = repository.getBidsForJob(jobId.toInt()).first()
    assertEquals(2, bids.size)

    val lowestBid = bids.minByOrNull { it.bidAmount }!!
    assertEquals(12500.0, lowestBid.bidAmount, 0.01)

    // Accept winning bid
    repository.acceptWinningBid(jobId.toInt(), lowestBid)

    val bookings = repository.allBookings.first()
    val awardedBooking = bookings.firstOrNull { it.machineryTitle == lowestBid.equipmentTitle }
    assertNotNull(awardedBooking)
    assertEquals(12500.0, awardedBooking!!.ownerNetEarnings, 0.01)
  }

  @Test
  fun `verify rental booking lifecycle and owner review submission`() = runBlocking {
    AppDatabase.populateDatabase(database)

    val machineryList = repository.allMachinery.first()
    val earthmover = machineryList.first { it.subCategory == "Excavator" }

    // 1. Create Booking with Date, Time, Location
    val bookingId = repository.createBooking(
      machinery = earthmover,
      jobLocation = "East Quarry Sector Hex #8828308285ff",
      jobUnits = 8.0,
      bookingDate = "Tomorrow, Sep 20",
      bookingTime = "06:00 AM - 02:00 PM"
    )
    assertTrue(bookingId > 0)

    val initialBooking = repository.allBookings.first().first { it.id == bookingId.toInt() }
    assertEquals("PENDING", initialBooking.status)
    assertEquals("Tomorrow, Sep 20", initialBooking.bookingDate)
    assertEquals("06:00 AM - 02:00 PM", initialBooking.bookingTime)
    assertEquals("East Quarry Sector Hex #8828308285ff", initialBooking.jobLocation)

    // 2. Advance through Milestones: PENDING -> MOBILIZING -> IN_PROGRESS -> COMPLETED
    repository.advanceBookingStatus(bookingId.toInt(), "PENDING")
    val mobilizingBooking = repository.allBookings.first().first { it.id == bookingId.toInt() }
    assertEquals("MOBILIZING", mobilizingBooking.status)

    repository.advanceBookingStatus(bookingId.toInt(), "MOBILIZING")
    val inProgressBooking = repository.allBookings.first().first { it.id == bookingId.toInt() }
    assertEquals("IN_PROGRESS", inProgressBooking.status)

    repository.advanceBookingStatus(bookingId.toInt(), "IN_PROGRESS")
    val completedBooking = repository.allBookings.first().first { it.id == bookingId.toInt() }
    assertEquals("COMPLETED", completedBooking.status)

    // 3. Submit Star Rating and Review for Machinery Owner
    repository.submitReview(
      bookingId = bookingId.toInt(),
      rating = 5,
      comment = "Operator arrived precisely at 6 AM, excavator was in pristine condition with GPS tracking active throughout.",
      tags = "On-Time Dispatch, Clean Cab, Skilled Operator"
    )

    val reviewedBooking = repository.allBookings.first().first { it.id == bookingId.toInt() }
    assertEquals(5, reviewedBooking.rating)
    assertEquals("Operator arrived precisely at 6 AM, excavator was in pristine condition with GPS tracking active throughout.", reviewedBooking.reviewComment)
    assertEquals("On-Time Dispatch, Clean Cab, Skilled Operator", reviewedBooking.reviewTags)
    assertNotNull(reviewedBooking.reviewedAt)
  }
}
