package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookingEntity
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen

val GoldenStarColor = Color(0xFFFFB300)

/**
 * Interactive Star Rating Bar (1 to 5 Stars) with touch feedback and accessible touch targets.
 */
@Composable
fun InteractiveStarRatingBar(
    rating: Int,
    onRatingChanged: (Int) -> Unit,
    modifier: Modifier = Modifier,
    maxStars: Int = 5,
    starSize: Int = 36,
    isReadOnly: Boolean = false
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..maxStars) {
            val isSelected = i <= rating
            val scale by animateFloatAsState(
                targetValue = if (isSelected) 1.15f else 1.0f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                label = "starScale_$i"
            )
            val tint by animateColorAsState(
                targetValue = if (isSelected) GoldenStarColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                label = "starColor_$i"
            )

            Box(
                modifier = Modifier
                    .size((starSize + 8).dp)
                    .then(
                        if (!isReadOnly) {
                            Modifier
                                .clickable { onRatingChanged(i) }
                                .testTag("star_button_$i")
                        } else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "$i of $maxStars Stars",
                    tint = tint,
                    modifier = Modifier
                        .size(starSize.dp)
                        .scale(if (!isReadOnly) scale else 1.0f)
                )
            }
        }
    }
}

/**
 * Descriptive label for selected star rating.
 */
fun getRatingSentiment(rating: Int): Pair<String, Color> {
    return when (rating) {
        5 -> "5.0 • Outstanding & Highly Recommended" to SuccessGreen
        4 -> "4.0 • Very Good Experience" to HighTechCyan
        3 -> "3.0 • Satisfactory Service" to IndustrialAmber
        2 -> "2.0 • Below Expectations" to Color(0xFFF97316)
        1 -> "1.0 • Poor Service" to Color(0xFFEF4444)
        else -> "Tap a star to rate operator" to Color.Gray
    }
}

/**
 * Full Star-Rating and Review Component for completed bookings.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OwnerReviewComponent(
    booking: BookingEntity,
    onSubmitReview: (rating: Int, comment: String, tags: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditing by remember { mutableStateOf(booking.rating == null) }
    var selectedStars by remember { mutableIntStateOf(booking.rating ?: 5) }
    var reviewText by remember { mutableStateOf(booking.reviewComment ?: "") }
    
    val quickTagOptions = listOf(
        "Punctual Operator",
        "Clean Equipment",
        "High Productivity",
        "Accurate Fuel Index",
        "Smooth Communication",
        "Safety Compliant"
    )
    
    val initialSelectedTags = remember(booking.reviewTags) {
        booking.reviewTags?.split(" • ")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
    }
    var selectedTags by remember { mutableStateOf(initialSelectedTags) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("owner_review_card_${booking.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (booking.rating != null) SuccessGreen.copy(alpha = 0.5f) else IndustrialAmber.copy(alpha = 0.6f)
            )
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = if (booking.rating != null) SuccessGreen.copy(alpha = 0.15f) else IndustrialAmber.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (booking.rating != null) Icons.Default.CheckCircle else Icons.Default.RateReview,
                                contentDescription = null,
                                tint = if (booking.rating != null) SuccessGreen else IndustrialAmber,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = if (booking.rating != null) "Owner Feedback & Review" else "Rate Machinery Owner",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "For ${booking.ownerName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (booking.rating != null && !isEditing) {
                    IconButton(
                        onClick = { isEditing = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Review",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (!isEditing && booking.rating != null) {
                // View Mode for Submitted Review
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            InteractiveStarRatingBar(
                                rating = booking.rating,
                                onRatingChanged = {},
                                isReadOnly = true,
                                starSize = 22
                            )
                            Text(
                                text = "${booking.rating}.0 / 5.0",
                                fontWeight = FontWeight.Bold,
                                color = GoldenStarColor,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Surface(
                                color = SuccessGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "VERIFIED REVIEW",
                                    color = SuccessGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (!booking.reviewTags.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                booking.reviewTags.split(" • ").forEach { tag ->
                                    if (tag.isNotBlank()) {
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                text = tag,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (!booking.reviewComment.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "\"${booking.reviewComment}\"",
                                style = MaterialTheme.typography.bodyMedium,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            } else {
                // Interactive Review Input Mode
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    InteractiveStarRatingBar(
                        rating = selectedStars,
                        onRatingChanged = { selectedStars = it },
                        starSize = 36
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val (sentimentText, sentimentColor) = getRatingSentiment(selectedStars)
                    Text(
                        text = sentimentText,
                        color = sentimentColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Feedback Chips
                    Text(
                        text = "What went well?",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        quickTagOptions.forEach { tag ->
                            val isSelected = selectedTags.contains(tag)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedTags = if (isSelected) {
                                        selectedTags - tag
                                    } else {
                                        selectedTags + tag
                                    }
                                },
                                label = { Text(tag, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndustrialAmber,
                                    selectedLabelColor = Color.White
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Review text area
                    OutlinedTextField(
                        value = reviewText,
                        onValueChange = { reviewText = it },
                        label = { Text("Write feedback for ${booking.ownerName}") },
                        placeholder = { Text("How was the machinery condition, operator punctuality, and site work?") },
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("review_comment_input_${booking.id}")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (booking.rating != null) {
                            TextButton(
                                onClick = { isEditing = false }
                            ) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        Button(
                            onClick = {
                                val tagsFormatted = selectedTags.joinToString(" • ")
                                onSubmitReview(selectedStars, reviewText.trim(), tagsFormatted)
                                isEditing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("submit_review_button_${booking.id}")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Submit Operator Review", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
