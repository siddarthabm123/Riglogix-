package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import com.example.data.local.BookingEntity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.FilledTonalButton
import com.example.ui.components.AllVehiclesVisualCatalogDialog
import com.example.ui.components.BookingSuccessConfirmationDialog
import com.example.ui.components.RealTimeBookingTracker
import com.example.ui.components.RentalBookingBottomSheet
import com.example.ui.components.VehiclePictureCard
import com.example.ui.components.VehiclePlainEnglishBadge
import com.example.ui.components.VehicleStructureExplainerDialog
import com.example.ui.components.VehicleVisualRepository
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.MachineryEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AntigravityViewModel
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MachineryHubScreen(
    viewModel: AntigravityViewModel,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
    isWideScreen: Boolean = false
) {
    val machineryList by viewModel.allMachinery.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val geofenceRadius by viewModel.geofenceRadiusKm.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedMachinery by viewModel.selectedMachinery.collectAsStateWithLifecycle()

    var showBookingDialogFor by remember { mutableStateOf<MachineryEntity?>(null) }
    var bookingSuccessConfirmation by remember { mutableStateOf<BookingSuccessInfo?>(null) }
    var liveTrackingBooking by remember { mutableStateOf<BookingEntity?>(null) }
    var showFilterSettings by remember { mutableStateOf(false) }
    var structureExplainerFor by remember { mutableStateOf<MachineryEntity?>(null) }
    var showAllVehiclesGuide by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    val categories = listOf(
        "All" to Icons.Default.Tune,
        "Agriculture" to Icons.Default.Agriculture,
        "Construction" to Icons.Default.Construction,
        "Logistics" to Icons.Default.LocalShipping
    )

    if (isWideScreen) {
        val activeMachinery = selectedMachinery ?: machineryList.firstOrNull()

        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Pane: Search, Category Chips & Equipment List
            Column(
                modifier = Modifier
                    .weight(1.15f)
                    .fillMaxSize()
            ) {
                // Search Bar & Filter Toggle
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search borewell rigs, 20-ton lorries, JCBs...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        } else {
                            IconButton(onClick = { showFilterSettings = !showFilterSettings }) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Geofence Settings",
                                    tint = if (showFilterSettings) IndustrialAmber else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_machinery_input_wide")
                )

                AnimatedVisibility(visible = showFilterSettings) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("H3 Geofence Radius", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("${geofenceRadius.toInt()} km", color = HighTechCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Slider(
                                value = geofenceRadius,
                                onValueChange = { viewModel.updateGeofenceRadius(it) },
                                valueRange = 10f..100f,
                                steps = 8,
                                colors = SliderDefaults.colors(thumbColor = HighTechCyan, activeTrackColor = HighTechCyan)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Categories Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { (category, icon) ->
                        val isSelected = selectedCategory.equals(category, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectCategory(category) },
                            label = { Text(category, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                            leadingIcon = { Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IndustrialAmber,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                    }
                }

                // Wide Screen Visual Guide Button
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, IndustrialAmber.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { showAllVehiclesGuide = true }
                        .testTag("wide_open_visual_vehicle_guide")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_heavy_excavator),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Column {
                                Text(
                                    text = "Visual Heavy Vehicle Guide",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndustrialAmber
                                )
                                Text(
                                    text = "Real pictures & simplified structure for every vehicle type",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = IndustrialAmber,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Available Machinery (${machineryList.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Select machine to inspect",
                        fontSize = 11.sp,
                        color = HighTechCyan
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(machineryList, key = { it.id }) { machinery ->
                        MachineryCard(
                            machinery = machinery,
                            onBookClick = {
                                viewModel.selectMachinery(machinery)
                            },
                            onDetailsClick = { viewModel.selectMachinery(machinery) },
                            onCallClick = {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${machinery.ownerPhone}")
                                }
                                context.startActivity(intent)
                            },
                            onOpenStructureExplainer = {
                                structureExplainerFor = machinery
                            }
                        )
                    }
                }
            }

            // Right Pane: Persistent Inspector & Direct Booking Panel
            Card(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxSize(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = CardDefaults.outlinedCardBorder()
            ) {
                if (activeMachinery != null) {
                    WideMachineryInspectorPanel(
                        machinery = activeMachinery,
                        onConfirmBooking = { location, units ->
                            viewModel.createBooking(
                                machinery = activeMachinery,
                                jobLocation = location,
                                jobUnits = units
                            ) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar(
                                        "Direct booking dispatched! ${activeMachinery.title} mobilized. Zero broker fee charged."
                                    )
                                }
                            }
                        },
                        onCallClick = {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${activeMachinery.ownerPhone}")
                            }
                            context.startActivity(intent)
                        },
                        onOpenStructureExplainer = {
                            structureExplainerFor = activeMachinery
                        }
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No machinery found within this radius.\nExpand geofence to view units.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .testTag("machinery_hub_list"),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
        // Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_machinery),
                    contentDescription = "Antigravity Heavy Fleet Hero",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = IndustrialAmber,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "DIRECT-TO-OWNER",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "0% MIDDLEMAN MARKUP",
                                color = HighTechCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Heavy Utility & Freight On-Demand",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Connect directly with verified rigs, excavators & commercial lorries",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Real-Time Active Rental Tracker Header Card if customer has bookings
        if (bookings.isNotEmpty()) {
            val activeBookings = bookings.filter { it.status != "COMPLETED" }
            val latestBooking = activeBookings.firstOrNull() ?: bookings.first()
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { liveTrackingBooking = latestBooking }
                        .testTag("active_rental_tracker_banner"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(HighTechCyan.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Sensors,
                                    contentDescription = null,
                                    tint = HighTechCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "LIVE RENTAL TRACKER",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = HighTechCyan
                                    )
                                    Surface(
                                        color = when (latestBooking.status) {
                                            "PENDING" -> HexagonBlue.copy(alpha = 0.2f)
                                            "MOBILIZING" -> IndustrialAmber.copy(alpha = 0.2f)
                                            "IN_PROGRESS" -> WarningYellow.copy(alpha = 0.2f)
                                            else -> SuccessGreen.copy(alpha = 0.2f)
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = latestBooking.status.replace("_", " "),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (latestBooking.status) {
                                                "PENDING" -> HexagonBlue
                                                "MOBILIZING" -> IndustrialAmber
                                                "IN_PROGRESS" -> WarningYellow
                                                else -> SuccessGreen
                                            },
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${latestBooking.machineryTitle} • ${latestBooking.jobLocation}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        FilledTonalButton(
                            onClick = { liveTrackingBooking = latestBooking },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Track", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Visual Vehicle Guide Card for non-technical customers
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { showAllVehiclesGuide = true }
                    .testTag("open_visual_vehicle_guide_banner"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, IndustrialAmber.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_borewell_rig),
                        contentDescription = "Visual Vehicle Guide",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Visibility,
                                contentDescription = null,
                                tint = IndustrialAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "NEW TO HEAVY VEHICLES?",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = IndustrialAmber,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Visual Vehicle Guide (Pictures & Structure)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "See real photos & plain-English structure — no confusing jargon!",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = IndustrialAmber,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Search Bar & Filter Toggle
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search borewell rigs, 20-ton lorries, JCBs...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        } else {
                            IconButton(onClick = { showFilterSettings = !showFilterSettings }) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Geofence Settings",
                                    tint = if (showFilterSettings) IndustrialAmber else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_machinery_input")
                )

                // Expandable Geofence Radius Slider
                AnimatedVisibility(visible = showFilterSettings) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.GpsFixed,
                                        contentDescription = null,
                                        tint = HighTechCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Dynamic Spatial Geofence",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Surface(
                                    color = HighTechCyan.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text(
                                        text = "${geofenceRadius.toInt()} km radius",
                                        color = HighTechCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "H3 hierarchical indexing matches only equipment with valid road classification clearances.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Slider(
                                value = geofenceRadius,
                                onValueChange = { viewModel.updateGeofenceRadius(it) },
                                valueRange = 10f..100f,
                                steps = 8,
                                colors = SliderDefaults.colors(
                                    thumbColor = HighTechCyan,
                                    activeTrackColor = HighTechCyan,
                                    inactiveTrackColor = MaterialTheme.colorScheme.outline
                                ),
                                modifier = Modifier.testTag("geofence_slider")
                            )
                        }
                    }
                }
            }
        }

        // Category Filter Chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { (category, icon) ->
                    val isSelected = selectedCategory.equals(category, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectCategory(category) },
                        label = { Text(category, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndustrialAmber,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White,
                            containerColor = MaterialTheme.colorScheme.surface,
                            labelColor = MaterialTheme.colorScheme.onSurface
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = MaterialTheme.colorScheme.outline,
                            selectedBorderColor = IndustrialAmber
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("filter_chip_$category")
                    )
                }
            }
        }

        // Header with count & Upfront pricing tag
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Nearby Verified Fleet (${machineryList.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "100% KYC Verified",
                        fontSize = 11.sp,
                        color = SuccessGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Machinery Cards List
        if (machineryList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Build,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No machinery found in this geofence",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Try increasing the matching radius slider above or clearing search filters.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                viewModel.updateSearchQuery("")
                                viewModel.selectCategory("All")
                                viewModel.updateGeofenceRadius(60f)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber)
                        ) {
                            Text("Expand Geofence to 60km")
                        }
                    }
                }
            }
        } else {
            items(machineryList, key = { it.id }) { machinery ->
                MachineryCard(
                    machinery = machinery,
                    onBookClick = { showBookingDialogFor = machinery },
                    onDetailsClick = { viewModel.selectMachinery(machinery) },
                    onCallClick = {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:${machinery.ownerPhone}")
                        }
                        context.startActivity(intent)
                    },
                    onOpenStructureExplainer = {
                        structureExplainerFor = machinery
                    }
                )
            }
        }
    }

    // Rental Booking Flow with Vehicle Selector, Date, Time, Location & Live Transparent Pricing
    showBookingDialogFor?.let { machinery ->
        RentalBookingBottomSheet(
            machinery = machinery,
            availableVehicles = machineryList,
            onDismiss = { showBookingDialogFor = null },
            onConfirmBooking = { selectedMachine, date, time, location, units ->
                viewModel.createBooking(
                    machinery = selectedMachine,
                    jobLocation = location,
                    jobUnits = units,
                    bookingDate = date,
                    bookingTime = time
                ) { newId ->
                    showBookingDialogFor = null
                    bookingSuccessConfirmation = BookingSuccessInfo(
                        bookingId = newId.toInt(),
                        machineTitle = selectedMachine.title,
                        scheduledDate = date,
                        scheduledTime = time,
                        location = location
                    )
                }
            }
        )
    }

    // Booking Success Confirmation Dialog with Immediate Live Tracking Call-to-Action
    bookingSuccessConfirmation?.let { info ->
        BookingSuccessConfirmationDialog(
            bookingId = info.bookingId,
            machineryTitle = info.machineTitle,
            scheduledDate = info.scheduledDate,
            scheduledTime = info.scheduledTime,
            jobLocation = info.location,
            onDismiss = { bookingSuccessConfirmation = null },
            onTrackLive = {
                val target = bookings.firstOrNull { it.id == info.bookingId } ?: bookings.firstOrNull()
                bookingSuccessConfirmation = null
                liveTrackingBooking = target
            }
        )
    }

    // Modal Live Tracking Dialog with Status, Stepper, Telematics & Star-Rating / Reviews
    liveTrackingBooking?.let { trackingBooking ->
        val currentBooking = bookings.firstOrNull { it.id == trackingBooking.id } ?: trackingBooking
        AlertDialog(
            onDismissRequest = { liveTrackingBooking = null },
            confirmButton = {
                TextButton(onClick = { liveTrackingBooking = null }) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                RealTimeBookingTracker(
                    booking = currentBooking,
                    onAdvanceMilestone = {
                        viewModel.advanceBooking(currentBooking.id, currentBooking.status)
                    },
                    onSubmitReview = { rating, comment, tags ->
                        viewModel.submitReview(currentBooking.id, rating, comment, tags) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Verified review submitted for ${currentBooking.ownerName}!")
                            }
                        }
                    }
                )
            }
        )
    }

    // Detail Bottom Sheet
    selectedMachinery?.let { machinery ->
        MachineryDetailBottomSheet(
            machinery = machinery,
            onDismiss = { viewModel.selectMachinery(null) },
            onBookClick = {
                val item = machinery
                viewModel.selectMachinery(null)
                showBookingDialogFor = item
            },
            onCallClick = {
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:${machinery.ownerPhone}")
                }
                context.startActivity(intent)
            }
        )
    }

    // Vehicle Structure Explainer Dialog for non-technical customers
    structureExplainerFor?.let { machinery ->
        VehicleStructureExplainerDialog(
            machinery = machinery,
            onDismiss = { structureExplainerFor = null },
            onBookClick = {
                val item = machinery
                structureExplainerFor = null
                showBookingDialogFor = item
            }
        )
    }

    // Complete Vehicle Visual Catalog Dialog
    if (showAllVehiclesGuide) {
        AllVehiclesVisualCatalogDialog(
            onDismiss = { showAllVehiclesGuide = false },
            onSelectVehicleType = { typeId ->
                when (typeId) {
                    "borewell_rig" -> viewModel.selectCategory("Agriculture")
                    "excavator" -> viewModel.selectCategory("Construction")
                    "tipper_truck" -> viewModel.selectCategory("Logistics")
                    else -> viewModel.selectCategory("Agriculture")
                }
            }
        )
    }
    }
}

@Composable
fun MachineryCard(
    machinery: MachineryEntity,
    onBookClick: () -> Unit,
    onDetailsClick: () -> Unit,
    onCallClick: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenStructureExplainer: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onDetailsClick() }
            .testTag("machinery_card_${machinery.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(
            listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Category, Distance, and H3 Hex Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (machinery.category) {
                        "Agriculture" -> SuccessGreen.copy(alpha = 0.15f)
                        "Construction" -> IndustrialAmber.copy(alpha = 0.15f)
                        else -> HexagonBlue.copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${machinery.category} • ${machinery.subCategory}",
                        color = when (machinery.category) {
                            "Agriculture" -> SuccessGreen
                            "Construction" -> IndustrialAmber
                            else -> HexagonBlue
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = HighTechCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.1f", machinery.distanceKm)} km away",
                        style = MaterialTheme.typography.labelSmall,
                        color = HighTechCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = machinery.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Vehicle Picture with Structure Breakdown button
            VehiclePictureCard(
                machinery = machinery,
                onOpenStructureExplainer = { onOpenStructureExplainer?.invoke() ?: onDetailsClick() }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Plain-English Explanation (Zero confusion for non-technical customers)
            VehiclePlainEnglishBadge(
                machinery = machinery,
                onSeeDetails = { onOpenStructureExplainer?.invoke() ?: onDetailsClick() }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Collapsible Technical Specifications for users who want deep stats
            var showDetailedSpecs by remember { mutableStateOf(false) }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showDetailedSpecs = !showDetailedSpecs }
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "Technical Specifications",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = if (showDetailedSpecs) "Hide ▲" else "View technical stats ▼",
                            fontSize = 10.sp,
                            color = HighTechCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (showDetailedSpecs) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = machinery.specs,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Road & Telematics indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.Shield,
                            contentDescription = null,
                            tint = HighTechCyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = machinery.roadClassification,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Owner details & Transparent Pricing
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Owner Info
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = machinery.ownerName,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Verified Owner",
                            tint = SuccessGreen,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = IndustrialAmber,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${machinery.ownerRating} (${machinery.completedJobs} jobs)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Price display
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "₹${machinery.ratePerUnit.toInt()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = " / ${machinery.rateUnit.replace("per ", "")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                    Text(
                        text = "+₹${machinery.baseRate.toInt()} base mobilization",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom CTA Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCallClick,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(0.35f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Icon(
                        Icons.Default.Phone,
                        contentDescription = "Call",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call", fontSize = 12.sp)
                }

                Button(
                    onClick = onBookClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                    modifier = Modifier
                        .weight(0.65f)
                        .testTag("book_button_${machinery.id}")
                ) {
                    Icon(
                        Icons.Default.Handshake,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Direct Book (0% Broker)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DirectBookingDialog(
    machinery: MachineryEntity,
    onDismiss: () -> Unit,
    onConfirm: (location: String, units: Double) -> Unit
) {
    var locationInput by remember { mutableStateOf("Site A, Sector Hex #8828308281ff") }
    var unitsInput by remember {
        mutableStateOf(
            when (machinery.rateUnit) {
                "per ft" -> "800"
                "per km" -> "150"
                "per hr" -> "6"
                else -> "1"
            }
        )
    }

    val units = unitsInput.toDoubleOrNull() ?: 1.0
    val basePrice = machinery.baseRate
    val servicePrice = machinery.ratePerUnit * units
    val fuelSurcharge = machinery.fuelIndexSurcharge
    val subtotal = basePrice + servicePrice + fuelSurcharge
    val antigravityFee = subtotal * 0.035 // 3.5%
    val totalCustomerCost = subtotal + antigravityFee
    val brokerWouldCharge = subtotal * 0.30 // 30% average middleman fee
    val savedCommission = brokerWouldCharge - antigravityFee

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Handshake,
                    contentDescription = null,
                    tint = IndustrialAmber
                )
                Text(
                    text = "Direct-to-Owner Booking",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = machinery.title,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Owner: ${machinery.ownerName} (${machinery.ownerPhone})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = locationInput,
                    onValueChange = { locationInput = it },
                    label = { Text("Job Location / Farm Site / Route") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = unitsInput,
                    onValueChange = { unitsInput = it },
                    label = {
                        Text(
                            when (machinery.rateUnit) {
                                "per ft" -> "Target Drilling Depth (Feet)"
                                "per km" -> "Logistics Distance (Kilometers)"
                                "per hr" -> "Estimated Operating Hours"
                                else -> "Units (${machinery.rateUnit})"
                            }
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Transparent Pricing Breakdown Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Upfront Transparent Pricing",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = HighTechCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        PriceRow("Base Mobilization", "₹${basePrice.toInt()}")
                        PriceRow("Work Cost (${units.toInt()} ${machinery.rateUnit})", "₹${servicePrice.toInt()}")
                        PriceRow("Fuel Index Surcharge", "₹${fuelSurcharge.toInt()}")
                        PriceRow("RigLogix Flat Fee (3.5%)", "₹${String.format(Locale("en", "IN"), "%.2f", antigravityFee)}")
                        
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 6.dp),
                            color = MaterialTheme.colorScheme.outline
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Total You Pay",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "₹${String.format(Locale("en", "IN"), "%.2f", totalCustomerCost)}",
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Owner Operator Receives",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${String.format(Locale("en", "IN"), "%.2f", subtotal)} (100% net)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = SuccessGreen
                            )
                        }

                        // Savings banner
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = SuccessGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "Saved ~₹${savedCommission.toInt()} vs traditional 30% broker cut",
                                    color = SuccessGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(locationInput, units) },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                modifier = Modifier.testTag("confirm_booking_button")
            ) {
                Text("Confirm Direct Booking")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun PriceRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MachineryDetailBottomSheet(
    machinery: MachineryEntity,
    onDismiss: () -> Unit,
    onBookClick: () -> Unit,
    onCallClick: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Surface(
                color = IndustrialAmber.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${machinery.category} • ${machinery.subCategory}",
                    color = IndustrialAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = machinery.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Vehicle Visual Explainer in Bottom Sheet
            VehiclePictureCard(machinery = machinery)

            Spacer(modifier = Modifier.height(8.dp))

            VehiclePlainEnglishBadge(machinery = machinery)

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = machinery.specs,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Telematics & Verification Matrix
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Verification & Telematics Status",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFeatureRow("Govt Commercial Vehicle Fitness", "VALID (Automated KYC)", SuccessGreen)
                    DetailFeatureRow("Owner KYC / AML Verified", "PASSED", SuccessGreen)
                    DetailFeatureRow("IoT GPS & OBD-II Active", "ONLINE (H3 Hex #${machinery.h3HexId})", HighTechCyan)
                    DetailFeatureRow("Road Grade Permitted", machinery.roadClassification, MaterialTheme.colorScheme.onSurface)
                    DetailFeatureRow("RigLogix Guarantee", "Escrow Protection & In-Transit Cover", HexagonBlue)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onCallClick,
                    modifier = Modifier.weight(0.4f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call Owner")
                }

                Button(
                    onClick = onBookClick,
                    modifier = Modifier.weight(0.6f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber)
                ) {
                    Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Instant Direct Book")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DetailFeatureRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
fun WideMachineryInspectorPanel(
    machinery: MachineryEntity,
    onConfirmBooking: (location: String, units: Double) -> Unit,
    onCallClick: () -> Unit,
    onOpenStructureExplainer: (() -> Unit)? = null
) {
    var locationInput by remember(machinery.id) { mutableStateOf("Site A, Sector Hex #8828308281ff") }
    var unitsInput by remember(machinery.id) {
        mutableStateOf(
            when (machinery.rateUnit) {
                "per ft" -> "800"
                "per km" -> "150"
                "per hr" -> "6"
                else -> "1"
            }
        )
    }

    val units = unitsInput.toDoubleOrNull() ?: 1.0
    val basePrice = machinery.baseRate
    val servicePrice = machinery.ratePerUnit * units
    val fuelSurcharge = machinery.fuelIndexSurcharge
    val subtotal = basePrice + servicePrice + fuelSurcharge
    val platformFee = subtotal * 0.035
    val totalCustomerCost = subtotal + platformFee
    val brokerWouldCharge = subtotal * 0.30
    val savedCommission = brokerWouldCharge - platformFee

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Header: Category Pill & Road Classification
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (machinery.category) {
                        "Agriculture" -> SuccessGreen.copy(alpha = 0.2f)
                        "Construction" -> IndustrialAmber.copy(alpha = 0.2f)
                        else -> HexagonBlue.copy(alpha = 0.2f)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${machinery.category.uppercase()} • ${machinery.subCategory}",
                        color = when (machinery.category) {
                            "Agriculture" -> SuccessGreen
                            "Construction" -> IndustrialAmber
                            else -> HexagonBlue
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(6.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Text(
                        text = "Radius: ${machinery.distanceKm.toInt()} km",
                        fontSize = 11.sp,
                        color = HighTechCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        item {
            Text(
                text = machinery.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Vehicle Picture in Inspector Panel
            VehiclePictureCard(
                machinery = machinery,
                onOpenStructureExplainer = { onOpenStructureExplainer?.invoke() }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Plain English Badge
            VehiclePlainEnglishBadge(
                machinery = machinery,
                onSeeDetails = { onOpenStructureExplainer?.invoke() }
            )
        }

        // Vehicle Structure Anatomy Preview (Laptop / Tablet)
        item {
            val guide = VehicleVisualRepository.getGuideForMachinery(machinery)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Build,
                                contentDescription = null,
                                tint = IndustrialAmber,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "Vehicle Anatomy & Key Components",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        TextButton(onClick = { onOpenStructureExplainer?.invoke() }) {
                            Text("Full Diagram", fontSize = 11.sp, color = HighTechCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    guide.structureParts.take(3).forEach { part ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = IndustrialAmber.copy(alpha = 0.15f),
                                shape = CircleShape,
                                modifier = Modifier.size(18.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("${part.partNumber}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = IndustrialAmber)
                                }
                            }
                            Text(
                                text = part.everydayName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "— ${part.plainDescription}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Owner Info Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = machinery.ownerName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = SuccessGreen,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "★ ${machinery.ownerRating} (${machinery.completedJobs} verified jobs)",
                            fontSize = 11.sp,
                            color = IndustrialAmber
                        )
                    }

                    OutlinedButton(
                        onClick = onCallClick,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Owner", fontSize = 11.sp)
                    }
                }
            }
        }

        // Interactive Booking Inputs
        item {
            Text(
                text = "Instant Direct Booking (0% Middleman)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = locationInput,
                onValueChange = { locationInput = it },
                label = { Text("Job Location / Farm Site / Route") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = unitsInput,
                onValueChange = { unitsInput = it },
                label = {
                    Text(
                        when (machinery.rateUnit) {
                            "per ft" -> "Target Drilling Depth (Feet)"
                            "per km" -> "Logistics Distance (Kilometers)"
                            "per hr" -> "Estimated Operating Hours"
                            else -> "Units (${machinery.rateUnit})"
                        }
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Live Cost & Broker Savings Breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE SMART COST LEDGER",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = HighTechCyan,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFeatureRow("Base Mobilization", "₹${basePrice.toInt()}", MaterialTheme.colorScheme.onSurface)
                    DetailFeatureRow("Service (${units.toInt()} ${machinery.rateUnit})", "₹${servicePrice.toInt()}", MaterialTheme.colorScheme.onSurface)
                    DetailFeatureRow("RigLogix Direct Fee (3.5%)", "₹${platformFee.toInt()}", HighTechCyan)

                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total to Pay", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = "₹${totalCustomerCost.toInt()}",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = SuccessGreen.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Savings, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = "You save ₹${savedCommission.toInt()} vs traditional 30% broker cut",
                                color = SuccessGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Mobilize CTA
        item {
            Button(
                onClick = { onConfirmBooking(locationInput, units) },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("wide_inspector_book_button")
            ) {
                Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Direct Dispatch Machine Now", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

data class BookingSuccessInfo(
    val bookingId: Int,
    val machineTitle: String,
    val scheduledDate: String,
    val scheduledTime: String,
    val location: String
)

