package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AlertRed
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen

@Composable
fun TransparencyScreen(
    modifier: Modifier = Modifier,
    isWideScreen: Boolean = false
) {
    var jobCostSlider by remember { mutableFloatStateOf(100000f) }

    val jobCost = jobCostSlider.toDouble()
    val brokerCutPercent = 0.30 // 30% average broker extortion
    val brokerFee = jobCost * brokerCutPercent
    val brokerOwnerGets = jobCost - brokerFee

    val antigravityCutPercent = 0.035 // 3.5% flat transparent fee
    val antigravityFee = jobCost * antigravityCutPercent
    val antigravityOwnerGets = jobCost

    val customerAndOwnerSavings = brokerFee - antigravityFee

    val inrFormatter = remember {
        java.text.NumberFormat.getCurrencyInstance(java.util.Locale("en", "IN")).apply {
            maximumFractionDigits = 0
        }
    }

    if (isWideScreen) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Pane: Hero & Economic Impact Calculator
            LazyColumn(
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // Hero Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = HighTechCyan,
                                    shape = CircleShape,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.VerifiedUser,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Disrupting Middlemen Monopoly",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Direct-to-Owner • 0% Broker Extortion",
                                        fontSize = 11.sp,
                                        color = HighTechCyan
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Traditional utility and heavy haulage brokers siphon 20% to 40% in arbitrary commissions without owning vehicles, maintaining machines, or assuming transit risk. RigLogix replaces them with code, H3 spatial telemetry, and transparent flat pricing.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Interactive Savings Simulator Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Real-World Economic Impact Calculator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Move the slider to compare financial outcomes across a real commercial heavy job",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Contract Value", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    inrFormatter.format(jobCost),
                                    fontWeight = FontWeight.Bold,
                                    color = HighTechCyan
                                )
                            }

                            Slider(
                                value = jobCostSlider,
                                onValueChange = { jobCostSlider = it },
                                valueRange = 10000f..500000f,
                                steps = 49,
                                colors = SliderDefaults.colors(
                                    thumbColor = HighTechCyan,
                                    activeTrackColor = HighTechCyan,
                                    inactiveTrackColor = MaterialTheme.colorScheme.outline
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Comparison Breakdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Broker Card
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, tint = AlertRed, modifier = Modifier.size(14.dp))
                                            Text("Old Broker System", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AlertRed)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Broker Take: 30%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("-${inrFormatter.format(brokerFee)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = AlertRed)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Owner Receives: ${inrFormatter.format(brokerOwnerGets)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                // RigLogix Card
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(12.dp),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SuccessGreen))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                                            Text("RigLogix Direct", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Flat Platform Fee: 3.5%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(inrFormatter.format(antigravityFee), fontSize = 16.sp, fontWeight = FontWeight.Black, color = HighTechCyan)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Owner Receives: ${inrFormatter.format(antigravityOwnerGets)}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = SuccessGreen)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                color = SuccessGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Savings, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = "${inrFormatter.format(customerAndOwnerSavings)} Net Savings Generated",
                                            fontWeight = FontWeight.Black,
                                            color = SuccessGreen,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "Zero kickbacks, zero haggling, zero hidden commissions.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right Pane: Technical Architecture Pillars
            LazyColumn(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                item {
                    Text(
                        text = "Technical Architecture",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    PillarCard(
                        icon = Icons.Default.GpsFixed,
                        iconTint = HighTechCyan,
                        title = "1. Dynamic Geofenced Matching Engine",
                        description = "Utilizes H3 (Uber's Hexagonal Hierarchical Spatial Index) for instant spatial matching. Geofence radius dynamically adapts (15km for borewell rigs, 80km for commercial lorries) while validating road weight classifications."
                    )
                }

                item {
                    PillarCard(
                        icon = Icons.Default.TrendingDown,
                        iconTint = IndustrialAmber,
                        title = "2. Upfront Pricing & Reverse Auction",
                        description = "Algorithmic base fare calculated from vehicle type, fuel index, and terrain difficulty. Non-urgent jobs enter a live downward bidding floor where nearby owners bid transparently to guarantee lowest market rate."
                    )
                }

                item {
                    PillarCard(
                        icon = Icons.Default.Shield,
                        iconTint = HexagonBlue,
                        title = "3. Verification & Trust Layer",
                        description = "Automated KYC/AML verification of commercial driver licenses, vehicle fitness, and insurance records. Hardware IoT OBD-II integration delivers real-time asset telemetry (speed, fuel, RPM, pressure)."
                    )
                }

                item {
                    PillarCard(
                        icon = Icons.Default.CloudQueue,
                        iconTint = SuccessGreen,
                        title = "4. Revenue Model (Decentralized & Fair)",
                        description = "1. Flat 3.5% transaction fee (vs 20-40% broker extortion).\n2. Optional Owner Pro subscriptions for priority matching and fleet analytics.\n3. In-app on-demand transit cargo insurance and operator micro-financing."
                    )
                }
            }
        }
    } else {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("transparency_view"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = IndustrialAmber,
                            shape = CircleShape,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MoneyOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(
                            text = "Cutting the Middleman",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Traditional contractors and freight brokers take 20-40% cuts without adding value. RigLogix connects you directly with verified owners with a flat, transparent 3.5% fee.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Interactive Commission Calculator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = HighTechCyan, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Interactive Savings Calculator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = IndustrialAmber.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${inrFormatter.format(jobCost)} Job",
                                color = IndustrialAmber,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Drag the slider to calculate how much money stays in the pockets of farmers, builders, and truck owners instead of middlemen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = jobCostSlider,
                        onValueChange = { jobCostSlider = it },
                        valueRange = 10000f..500000f,
                        steps = 49,
                        colors = SliderDefaults.colors(
                            thumbColor = IndustrialAmber,
                            activeTrackColor = IndustrialAmber,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    // Side-by-side comparison
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Traditional Broker Card
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = AlertRed, modifier = Modifier.size(14.dp))
                                    Text("Old Broker System", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AlertRed)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Broker Take: 30%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("-${inrFormatter.format(brokerFee)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = AlertRed)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Owner Receives: ${inrFormatter.format(brokerOwnerGets)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        // RigLogix Card
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SuccessGreen))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                                    Text("RigLogix Direct", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Flat Platform Fee: 3.5%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(inrFormatter.format(antigravityFee), fontSize = 16.sp, fontWeight = FontWeight.Black, color = HighTechCyan)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Owner Receives: ${inrFormatter.format(antigravityOwnerGets)}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = SuccessGreen)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = SuccessGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Savings, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(24.dp))
                            Column {
                                Text(
                                    text = "${inrFormatter.format(customerAndOwnerSavings)} Net Savings Generated",
                                    fontWeight = FontWeight.Black,
                                    color = SuccessGreen,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Zero kickbacks, zero haggling, zero hidden commissions.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Architecture Pillars
        item {
            Text(
                text = "Technical Architecture",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            PillarCard(
                icon = Icons.Default.GpsFixed,
                iconTint = HighTechCyan,
                title = "1. Dynamic Geofenced Matching Engine",
                description = "Utilizes H3 (Uber's Hexagonal Hierarchical Spatial Index) for instant spatial matching. Geofence radius dynamically adapts (15km for borewell rigs, 80km for commercial lorries) while validating road weight classifications."
            )
        }

        item {
            PillarCard(
                icon = Icons.Default.TrendingDown,
                iconTint = IndustrialAmber,
                title = "2. Upfront Pricing & Reverse Auction",
                description = "Algorithmic base fare calculated from vehicle type, fuel index, and terrain difficulty. Non-urgent jobs enter a live downward bidding floor where nearby owners bid transparently to guarantee lowest market rate."
            )
        }

        item {
            PillarCard(
                icon = Icons.Default.Shield,
                iconTint = HexagonBlue,
                title = "3. Verification & Trust Layer",
                description = "Automated KYC/AML verification of commercial driver licenses, vehicle fitness, and insurance records. Hardware IoT OBD-II integration delivers real-time asset telemetry (speed, fuel, RPM, pressure)."
            )
        }

        item {
            PillarCard(
                icon = Icons.Default.CloudQueue,
                iconTint = SuccessGreen,
                title = "4. Revenue Model (Decentralized & Fair)",
                description = "1. Flat 3.5% transaction fee (vs 20-40% broker extortion).\n2. Optional Owner Pro subscriptions for priority matching and fleet analytics.\n3. In-app on-demand transit cargo insurance and operator micro-financing."
            )
        }
    }
    }
}

@Composable
fun PillarCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = iconTint.copy(alpha = 0.15f),
                shape = CircleShape,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
