package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AuctionBidEntity
import com.example.data.local.AuctionJobEntity
import com.example.data.local.BookingEntity
import com.example.data.local.MachineryEntity
import com.example.data.local.OwnerFleetEntity
import com.example.data.repository.AntigravityRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class UserRole {
    CUSTOMER,
    OWNER_OPERATOR
}

enum class DisplayInterfaceMode(val label: String, val shortLabel: String) {
    AUTO("Auto (Responsive)", "Auto"),
    PHONE("Phone (Compact)", "Phone"),
    TABLET("Tablet (Dual-Pane)", "Tablet"),
    LAPTOP("Laptop / Desktop (Expanded)", "Laptop")
}

class AntigravityViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AntigravityRepository

    private val _displayMode = MutableStateFlow(DisplayInterfaceMode.AUTO)
    val displayMode: StateFlow<DisplayInterfaceMode> = _displayMode.asStateFlow()

    private val _userRole = MutableStateFlow(UserRole.CUSTOMER)
    val userRole: StateFlow<UserRole> = _userRole.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _geofenceRadiusKm = MutableStateFlow(35f)
    val geofenceRadiusKm: StateFlow<Float> = _geofenceRadiusKm.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedJobId = MutableStateFlow<Int?>(1)
    val selectedJobId: StateFlow<Int?> = _selectedJobId.asStateFlow()

    private val _selectedMachinery = MutableStateFlow<MachineryEntity?>(null)
    val selectedMachinery: StateFlow<MachineryEntity?> = _selectedMachinery.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = AntigravityRepository(database)
        viewModelScope.launch {
            repository.checkAndSeedIfEmpty()
        }
    }

    val allMachinery: StateFlow<List<MachineryEntity>> = combine(
        repository.allMachinery,
        _selectedCategory,
        _geofenceRadiusKm,
        _searchQuery
    ) { list, category, radius, query ->
        list.filter { item ->
            val matchesCategory = if (category == "All") true else item.category.equals(category, ignoreCase = true)
            val matchesRadius = item.distanceKm <= radius
            val matchesQuery = if (query.isBlank()) true else {
                item.title.contains(query, ignoreCase = true) ||
                item.subCategory.contains(query, ignoreCase = true) ||
                item.specs.contains(query, ignoreCase = true) ||
                item.ownerName.contains(query, ignoreCase = true)
            }
            matchesCategory && matchesRadius && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val bookings: StateFlow<List<BookingEntity>> = repository.allBookings
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val auctionJobs: StateFlow<List<AuctionJobEntity>> = repository.allAuctionJobs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val ownerFleet: StateFlow<List<OwnerFleetEntity>> = repository.allFleet
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedJobBids: StateFlow<List<AuctionBidEntity>> = _selectedJobId.flatMapLatest { jobId ->
        if (jobId != null) {
            repository.getBidsForJob(jobId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setDisplayMode(mode: DisplayInterfaceMode) {
        _displayMode.value = mode
    }

    fun switchRole(role: UserRole) {
        _userRole.value = role
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateGeofenceRadius(radius: Float) {
        _geofenceRadiusKm.value = radius
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectMachinery(machinery: MachineryEntity?) {
        _selectedMachinery.value = machinery
    }

    fun selectJob(jobId: Int?) {
        _selectedJobId.value = jobId
    }

    private val _trackingBookingId = MutableStateFlow<Int?>(null)
    val trackingBookingId: StateFlow<Int?> = _trackingBookingId.asStateFlow()

    fun setTrackingBookingId(id: Int?) {
        _trackingBookingId.value = id
    }

    fun createBooking(
        machinery: MachineryEntity,
        jobLocation: String,
        jobUnits: Double,
        bookingDate: String = "Today, Sep 19",
        bookingTime: String = "08:00 AM",
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.createBooking(
                machinery = machinery,
                jobLocation = jobLocation,
                jobUnits = jobUnits,
                bookingDate = bookingDate,
                bookingTime = bookingTime
            )
            _selectedMachinery.value = null
            _trackingBookingId.value = id.toInt()
            onSuccess(id)
        }
    }

    fun advanceBooking(bookingId: Int, currentStatus: String) {
        viewModelScope.launch {
            repository.advanceBookingStatus(bookingId, currentStatus)
        }
    }

    fun submitReview(
        bookingId: Int,
        rating: Int,
        comment: String,
        tags: String = "",
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.submitReview(bookingId, rating, comment, tags)
            onSuccess()
        }
    }

    fun createAuctionJob(
        title: String,
        category: String,
        location: String,
        details: String,
        ceilingPrice: Double,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.createAuctionJob(title, category, location, details, ceilingPrice)
            _selectedJobId.value = id.toInt()
            onSuccess(id)
        }
    }

    fun submitDownwardBid(
        jobId: Int,
        operatorName: String,
        operatorPhone: String,
        operatorRating: Double,
        equipmentTitle: String,
        bidAmount: Double,
        etaMinutes: Int,
        h3DistanceKm: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.submitBid(
                jobId = jobId,
                operatorName = operatorName,
                operatorPhone = operatorPhone,
                operatorRating = operatorRating,
                equipmentTitle = equipmentTitle,
                bidAmount = bidAmount,
                etaMinutes = etaMinutes,
                h3DistanceKm = h3DistanceKm
            )
            onSuccess()
        }
    }

    fun acceptBid(jobId: Int, bid: AuctionBidEntity, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.acceptWinningBid(jobId, bid)
            onSuccess()
        }
    }

    fun addFleetEquipment(
        title: String,
        category: String,
        regNumber: String,
        capacity: String,
        rate: Double,
        rateUnit: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val item = OwnerFleetEntity(
                title = title,
                category = category,
                regNumber = regNumber,
                capacity = capacity,
                hourlyOrKmRate = rate,
                rateUnit = rateUnit,
                isOnline = true,
                currentJob = "Available",
                fuelLevelPercent = 90,
                engineHours = 120,
                telematicsIotId = "OBD2-AG-${System.currentTimeMillis() % 10000}"
            )
            repository.addFleetEquipment(item)
            onSuccess()
        }
    }

    fun toggleFleetOnline(fleetId: Int, isOnline: Boolean) {
        viewModelScope.launch {
            repository.toggleFleetOnline(fleetId, isOnline)
        }
    }
}
