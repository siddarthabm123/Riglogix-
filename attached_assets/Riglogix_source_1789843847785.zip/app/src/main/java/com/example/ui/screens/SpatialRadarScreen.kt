package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.BookingEntity
import com.example.data.local.MachineryEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SlateDark700
import com.example.ui.components.RealTimeBookingTracker
import com.example.ui.components.RentalBookingBottomSheet
import com.example.ui.theme.SlateDark900
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AntigravityViewModel
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpatialRadarScreen(
    viewModel: AntigravityViewModel,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
    isWideScreen: Boolean = false
) {
    val machineryList by viewModel.allMachinery.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val coroutineScope = rememberCoroutineScope()

    var selectedMachineryNode by remember { mutableStateOf<MachineryEntity?>(machineryList.firstOrNull()) }
    var rentalBookingMachine by remember { mutableStateOf<MachineryEntity?>(null) }

    // Pulsing radar animation
    val infiniteTransition = rememberInfiniteTransition(label = "radarPulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    if (isWideScreen) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Pane: Radar Canvas & H3 Info
            LazyColumn(
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // Spatial Matching Engine Info
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.Sensors,
                                    contentDescription = null,
                                    tint = HighTechCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "H3 Hierarchical Spatial Indexing",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Dynamic geofences tuned to equipment mobility: 15km for specialized high-pressure drilling rigs, 35km for excavators, 80km for 20-ton commercial lorries. Real-time road clearance validation.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Interactive Radar Canvas
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(360.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SlateDark900)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Canvas(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(machineryList) {
                                        detectTapGestures { offset ->
                                            val centerX = size.width / 2f
                                            val centerY = size.height / 2f
                                            val radiusMax = size.width.coerceAtMost(size.height) * 0.44f
                                            machineryList.forEachIndexed { index, machine ->
                                                val angle = (index * 45.0) * (Math.PI / 180.0)
                                                val distFraction = (machine.distanceKm / 40.0).coerceIn(0.2, 0.95)
                                                val nodeX = (centerX + cos(angle) * (radiusMax * distFraction)).toFloat()
                                                val nodeY = (centerY + sin(angle) * (radiusMax * distFraction)).toFloat()
                                                val dx = nodeX - offset.x
                                                val dy = nodeY - offset.y
                                                val touchDist = kotlin.math.sqrt(dx * dx + dy * dy)
                                                if (touchDist <= 40f) {
                                                    selectedMachineryNode = machine
                                                }
                                            }
                                        }
                                    }
                            ) {
                                val centerX = size.width / 2f
                                val centerY = size.height / 2f
                                val maxRadius = (size.width.coerceAtMost(size.height)) * 0.44f

                                val ringColors = listOf(
                                    Color(0x3300C9A7) to "15km Borewell",
                                    Color(0x223A86FF) to "35km Earthmoving",
                                    Color(0x19FF6B00) to "80km Lorry Corridor"
                                )
                                val ringScales = listOf(0.35f, 0.65f, 0.95f)

                                ringScales.forEachIndexed { i, scale ->
                                    drawCircle(
                                        color = ringColors[i].first,
                                        radius = maxRadius * scale,
                                        center = Offset(centerX, centerY),
                                        style = Stroke(width = 2f)
                                    )
                                }

                                drawCircle(
                                    color = HighTechCyan.copy(alpha = (1f - pulseRadius) * 0.4f),
                                    radius = maxRadius * pulseRadius,
                                    center = Offset(centerX, centerY),
                                    style = Stroke(width = 3f)
                                )

                                drawLine(
                                    color = Color(0x22FFFFFF),
                                    start = Offset(centerX - maxRadius, centerY),
                                    end = Offset(centerX + maxRadius, centerY),
                                    strokeWidth = 1f
                                )
                                drawLine(
                                    color = Color(0x22FFFFFF),
                                    start = Offset(centerX, centerY - maxRadius),
                                    end = Offset(centerX, centerY + maxRadius),
                                    strokeWidth = 1f
                                )

                                val hexRadius = 36f
                                val hexOffsets = listOf(
                                    Offset(centerX - 70f, centerY - 60f),
                                    Offset(centerX + 60f, centerY - 70f),
                                    Offset(centerX - 80f, centerY + 50f),
                                    Offset(centerX + 75f, centerY + 55f)
                                )
                                hexOffsets.forEach { hexCenter ->
                                    val hexPath = Path()
                                    for (p in 0..5) {
                                        val rad = (60.0 * p) * (Math.PI / 180.0)
                                        val px = (hexCenter.x + hexRadius * cos(rad)).toFloat()
                                        val py = (hexCenter.y + hexRadius * sin(rad)).toFloat()
                                        if (p == 0) hexPath.moveTo(px, py) else hexPath.lineTo(px, py)
                                    }
                                    hexPath.close()
                                    drawPath(
                                        path = hexPath,
                                        color = HexagonBlue.copy(alpha = 0.25f),
                                        style = Stroke(width = 1.5f)
                                    )
                                }

                                drawCircle(
                                    color = Color.White,
                                    radius = 6f,
                                    center = Offset(centerX, centerY)
                                )
                                drawCircle(
                                    color = IndustrialAmber,
                                    radius = 12f,
                                    center = Offset(centerX, centerY),
                                    style = Stroke(width = 3f)
                                )

                                machineryList.forEachIndexed { index, machine ->
                                    val angle = (index * 45.0) * (Math.PI / 180.0)
                                    val distFraction = (machine.distanceKm / 40.0).coerceIn(0.25, 0.92)
                                    val nodeX = (centerX + cos(angle) * (maxRadius * distFraction)).toFloat()
                                    val nodeY = (centerY + sin(angle) * (maxRadius * distFraction)).toFloat()

                                    val nodeColor = when (machine.category) {
                                        "Agriculture" -> SuccessGreen
                                        "Construction" -> IndustrialAmber
                                        else -> HexagonBlue
                                    }

                                    val isSelected = machine.id == selectedMachineryNode?.id

                                    if (isSelected) {
                                        drawCircle(
                                            color = Color.White.copy(alpha = 0.4f),
                                            radius = 18f,
                                            center = Offset(nodeX, nodeY)
                                        )
                                    }

                                    drawCircle(
                                        color = nodeColor,
                                        radius = if (isSelected) 10f else 7f,
                                        center = Offset(nodeX, nodeY)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(12.dp)
                            ) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = "LIVE H3 RADAR",
                                            color = HighTechCyan,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Base: Hex #8828308281ff",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Click nodes to inspect telemetry",
                                            color = Color.LightGray,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right Pane: Telematics Node Inspector & Active Operations
            LazyColumn(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                selectedMachineryNode?.let { machine ->
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(HighTechCyan))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "IoT Telematics: ${machine.title}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Operator: ${machine.ownerName} • ${machine.distanceKm} km away",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Surface(
                                        color = SuccessGreen.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                                            Text("OBD-II LIVE", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    TelemetryBox(
                                        title = "Road Clearance",
                                        value = if (machine.category == "Logistics") "Highway Clr" else "Heavy Rig Ok",
                                        modifier = Modifier.weight(1f)
                                    )
                                    TelemetryBox(
                                        title = "Fuel Status",
                                        value = "88% Diesel",
                                        modifier = Modifier.weight(1f)
                                    )
                                    TelemetryBox(
                                        title = "Engine RPM",
                                        value = "1,840 RPM",
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    TelemetryBox(
                                        title = "Hydraulic PSI",
                                        value = "3,200 PSI",
                                        modifier = Modifier.weight(1f)
                                    )
                                    TelemetryBox(
                                        title = "Coolant Temp",
                                        value = "84°C Normal",
                                        modifier = Modifier.weight(1f)
                                    )
                                    TelemetryBox(
                                        title = "GPS Lock",
                                        value = "12 Satellites",
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "H3 Hex: ${machine.h3HexId} • Radius: 35km",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Button(
                                        onClick = {
                                            rentalBookingMachine = machine
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Mobilize Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Active Heavy Logistics & Rig Trackers (${bookings.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (bookings.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = "No active machinery dispatched yet. Book from the Machinery Hub to track live mobilization.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(bookings, key = { it.id }) { booking ->
                        RealTimeBookingTracker(
                            booking = booking,
                            onAdvanceMilestone = {
                                viewModel.advanceBooking(booking.id, booking.status)
                            },
                            onSubmitReview = { rating, comment, tags ->
                                viewModel.submitReview(booking.id, rating, comment, tags) {
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Verified review submitted for ${booking.ownerName}!")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    } else {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("spatial_radar_view"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Spatial Matching Engine Info
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Sensors,
                            contentDescription = null,
                            tint = HighTechCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "H3 Hierarchical Spatial Indexing",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Dynamic geofences tuned to equipment mobility: 15km for specialized high-pressure drilling rigs, 35km for excavators, 80km for 20-ton commercial lorries. Real-time road clearance validation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Interactive Radar Canvas
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SlateDark900)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(machineryList) {
                                detectTapGestures { offset ->
                                    val centerX = size.width / 2f
                                    val centerY = size.height / 2f
                                    val radiusMax = size.width.coerceAtMost(size.height) * 0.44f
                                    // Detect which machine was clicked
                                    machineryList.forEachIndexed { index, machine ->
                                        val angle = (index * 45.0) * (Math.PI / 180.0)
                                        val distFraction = (machine.distanceKm / 40.0).coerceIn(0.2, 0.95)
                                        val nodeX = (centerX + cos(angle) * (radiusMax * distFraction)).toFloat()
                                        val nodeY = (centerY + sin(angle) * (radiusMax * distFraction)).toFloat()
                                        val dx = nodeX - offset.x
                                        val dy = nodeY - offset.y
                                        val touchDist = kotlin.math.sqrt(dx * dx + dy * dy)
                                        if (touchDist <= 40f) {
                                            selectedMachineryNode = machine
                                        }
                                    }
                                }
                            }
                    ) {
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        val maxRadius = (size.width.coerceAtMost(size.height)) * 0.44f

                        // Draw background concentric geofence rings
                        val ringColors = listOf(
                            Color(0x3300C9A7) to "15km Borewell",
                            Color(0x223A86FF) to "35km Earthmoving",
                            Color(0x19FF6B00) to "80km Lorry Corridor"
                        )
                        val ringScales = listOf(0.35f, 0.65f, 0.95f)

                        ringScales.forEachIndexed { i, scale ->
                            drawCircle(
                                color = ringColors[i].first,
                                radius = maxRadius * scale,
                                center = Offset(centerX, centerY),
                                style = Stroke(width = 2f)
                            )
                        }

                        // Pulsing radar sweep
                        drawCircle(
                            color = HighTechCyan.copy(alpha = (1f - pulseRadius) * 0.4f),
                            radius = maxRadius * pulseRadius,
                            center = Offset(centerX, centerY),
                            style = Stroke(width = 3f)
                        )

                        // Crosshairs
                        drawLine(
                            color = Color(0x22FFFFFF),
                            start = Offset(centerX - maxRadius, centerY),
                            end = Offset(centerX + maxRadius, centerY),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = Color(0x22FFFFFF),
                            start = Offset(centerX, centerY - maxRadius),
                            end = Offset(centerX, centerY + maxRadius),
                            strokeWidth = 1f
                        )

                        // Draw H3 Hexagonal Grid Outlines
                        val hexRadius = 36f
                        val hexOffsets = listOf(
                            Offset(centerX - 70f, centerY - 60f),
                            Offset(centerX + 60f, centerY - 70f),
                            Offset(centerX - 80f, centerY + 50f),
                            Offset(centerX + 75f, centerY + 55f)
                        )
                        hexOffsets.forEach { hexCenter ->
                            val hexPath = Path()
                            for (p in 0..5) {
                                val rad = (60.0 * p) * (Math.PI / 180.0)
                                val px = (hexCenter.x + hexRadius * cos(rad)).toFloat()
                                val py = (hexCenter.y + hexRadius * sin(rad)).toFloat()
                                if (p == 0) hexPath.moveTo(px, py) else hexPath.lineTo(px, py)
                            }
                            hexPath.close()
                            drawPath(
                                path = hexPath,
                                color = HexagonBlue.copy(alpha = 0.25f),
                                style = Stroke(width = 1.5f)
                            )
                        }

                        // Center User Node
                        drawCircle(
                            color = Color.White,
                            radius = 6f,
                            center = Offset(centerX, centerY)
                        )
                        drawCircle(
                            color = IndustrialAmber,
                            radius = 12f,
                            center = Offset(centerX, centerY),
                            style = Stroke(width = 3f)
                        )

                        // Draw Machinery Nodes
                        machineryList.forEachIndexed { index, machine ->
                            val angle = (index * 45.0) * (Math.PI / 180.0)
                            val distFraction = (machine.distanceKm / 40.0).coerceIn(0.25, 0.92)
                            val nodeX = (centerX + cos(angle) * (maxRadius * distFraction)).toFloat()
                            val nodeY = (centerY + sin(angle) * (maxRadius * distFraction)).toFloat()

                            val nodeColor = when (machine.category) {
                                "Agriculture" -> SuccessGreen
                                "Construction" -> IndustrialAmber
                                else -> HexagonBlue
                            }

                            val isSelected = machine.id == selectedMachineryNode?.id

                            if (isSelected) {
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.4f),
                                    radius = 18f,
                                    center = Offset(nodeX, nodeY)
                                )
                            }

                            drawCircle(
                                color = nodeColor,
                                radius = if (isSelected) 10f else 7f,
                                center = Offset(nodeX, nodeY)
                            )
                        }
                    }

                    // Radar Overlay Legend
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "LIVE H3 RADAR",
                                    color = HighTechCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Base: Hex #8828308281ff",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Tap nodes to inspect telemetry",
                                    color = Color.LightGray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Selected Machine Telematics & IoT OBD-II Card
        selectedMachineryNode?.let { machine ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(HighTechCyan))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "IoT Telematics: ${machine.title}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Operator: ${machine.ownerName} • ${machine.distanceKm} km away",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                color = SuccessGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                                    Text("OBD-II LIVE", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Telemetry Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TelemetryBox(
                                title = "Road Clearance",
                                value = if (machine.category == "Logistics") "Highway Clr" else "Heavy Rig Ok",
                                modifier = Modifier.weight(1f)
                            )
                            TelemetryBox(
                                title = "Fuel Status",
                                value = "88% Diesel",
                                modifier = Modifier.weight(1f)
                            )
                            TelemetryBox(
                                title = "Engine Health",
                                value = "Optimal 0 DTC",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "H3 Hex: ${machine.h3HexId} • Radius: 35km",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Button(
                                onClick = {
                                    rentalBookingMachine = machine
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Mobilize Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Active Booking Milestones Lifecycle
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Active Heavy Logistics & Rig Trackers (${bookings.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (bookings.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No active machinery dispatched yet. Book from the Machinery Hub to track live mobilization.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(bookings, key = { it.id }) { booking ->
                RealTimeBookingTracker(
                    booking = booking,
                    onAdvanceMilestone = {
                        viewModel.advanceBooking(booking.id, booking.status)
                    },
                    onSubmitReview = { rating, comment, tags ->
                        viewModel.submitReview(booking.id, rating, comment, tags) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Verified review submitted for ${booking.ownerName}!")
                            }
                        }
                    }
                )
            }
        }
    }
    }

    // Rental Booking Bottom Sheet with Date, Time, Location & Transparent Pricing
    rentalBookingMachine?.let { machine ->
        RentalBookingBottomSheet(
            machinery = machine,
            availableVehicles = machineryList,
            onDismiss = { rentalBookingMachine = null },
            onConfirmBooking = { selectedMachine, date, time, location, units ->
                viewModel.createBooking(
                    machinery = selectedMachine,
                    jobLocation = location,
                    jobUnits = units,
                    bookingDate = date,
                    bookingTime = time
                ) {
                    rentalBookingMachine = null
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Rental scheduled for ${selectedMachine.title}! Status: Pending.")
                    }
                }
            }
        )
    }
}

@Composable
fun TelemetryBox(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = title, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = HighTechCyan)
        }
    }
}

@Composable
fun BookingTrackerCard(
    booking: BookingEntity,
    onAdvanceMilestone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("booking_card_${booking.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (booking.status) {
                        "CONFIRMED" -> HexagonBlue.copy(alpha = 0.15f)
                        "MOBILIZING" -> IndustrialAmber.copy(alpha = 0.15f)
                        "ON_SITE" -> HighTechCyan.copy(alpha = 0.15f)
                        "IN_PROGRESS" -> WarningYellow.copy(alpha = 0.15f)
                        else -> SuccessGreen.copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = booking.status.replace("_", " "),
                        color = when (booking.status) {
                            "CONFIRMED" -> HexagonBlue
                            "MOBILIZING" -> IndustrialAmber
                            "ON_SITE" -> HighTechCyan
                            "IN_PROGRESS" -> WarningYellow
                            else -> SuccessGreen
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = booking.bookingDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = booking.machineryTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Site: ${booking.jobLocation}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Real-time telematics status string
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.Speed,
                        contentDescription = null,
                        tint = HighTechCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = booking.telematicsStatus,
                        fontSize = 11.sp,
                        color = HighTechCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Cost and advance milestone button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total: ₹${booking.totalCustomerCost.toInt()}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Operator gets ₹${booking.ownerNetEarnings.toInt()} (3.5% fee)",
                        fontSize = 10.sp,
                        color = SuccessGreen
                    )
                }

                if (booking.status != "COMPLETED") {
                    Button(
                        onClick = onAdvanceMilestone,
                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("advance_milestone_button_${booking.id}")
                    ) {
                        Icon(Icons.Default.Route, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Next Milestone", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Surface(
                        color = SuccessGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Job Completed & Settled", fontSize = 11.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

val WarningYellow = Color(0xFFF59E0B)
