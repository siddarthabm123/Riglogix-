package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = IndustrialAmber,
    onPrimary = Color.White,
    primaryContainer = IndustrialAmberDark,
    onPrimaryContainer = Color.White,
    secondary = HighTechCyan,
    onSecondary = Color.Black,
    secondaryContainer = SlateDark600,
    onSecondaryContainer = HighTechCyanLight,
    tertiary = HexagonBlue,
    background = SlateDark900,
    onBackground = TextPrimaryDark,
    surface = SlateDark800,
    onSurface = TextPrimaryDark,
    surfaceVariant = SlateDark700,
    onSurfaceVariant = TextSecondaryDark,
    outline = SlateBorder,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = IndustrialAmberDark,
    onPrimary = Color.White,
    primaryContainer = IndustrialAmberLight,
    onPrimaryContainer = Color.White,
    secondary = HighTechCyan,
    onSecondary = Color.White,
    secondaryContainer = SlateLight200,
    onSecondaryContainer = TextPrimaryLight,
    tertiary = HexagonBlue,
    background = SlateLight100,
    onBackground = TextPrimaryLight,
    surface = Color.White,
    onSurface = TextPrimaryLight,
    surfaceVariant = SlateLight200,
    onSurfaceVariant = TextSecondaryLight,
    outline = SlateLight300,
  )

@Composable
fun AntigravityTheme(
  darkTheme: Boolean = true, // Defaulting to sleek dark industrial UI for Antigravity
  dynamicColor: Boolean = false, // Keep consistent industrial brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

