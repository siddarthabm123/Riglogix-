package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.AuctionBidEntity
import com.example.data.local.AuctionJobEntity
import com.example.data.local.BookingEntity
import com.example.data.local.MachineryEntity
import com.example.data.local.OwnerFleetEntity
import kotlinx.coroutines.flow.Flow

class AntigravityRepository(private val database: AppDatabase) {

    private val machineryDao = database.machineryDao()
    private val bookingDao = database.bookingDao()
    private val auctionDao = database.auctionDao()
    private val fleetDao = database.fleetDao()

    val allMachinery: Flow<List<MachineryEntity>> = machineryDao.getAllMachinery()
    val allBookings: Flow<List<BookingEntity>> = bookingDao.getAllBookings()
    val allAuctionJobs: Flow<List<AuctionJobEntity>> = auctionDao.getAllAuctionJobs()
    val allFleet: Flow<List<OwnerFleetEntity>> = fleetDao.getAllFleet()

    fun getBidsForJob(jobId: Int): Flow<List<AuctionBidEntity>> = auctionDao.getBidsForJob(jobId)

    suspend fun checkAndSeedIfEmpty() {
        AppDatabase.populateDatabase(database)
    }

    suspend fun createBooking(
        machinery: MachineryEntity,
        jobLocation: String,
        jobUnits: Double,
        bookingDate: String = "Today, Sep 19",
        bookingTime: String = "08:00 AM"
    ): Long {
        val basePrice = machinery.baseRate
        val servicePrice = machinery.ratePerUnit * jobUnits
        val fuelSurcharge = machinery.fuelIndexSurcharge
        val subtotal = basePrice + servicePrice + fuelSurcharge
        val antigravityFee = subtotal * 0.035 // Flat 3.5%
        val totalCustomerCost = subtotal + antigravityFee
        val ownerNetEarnings = subtotal

        val booking = BookingEntity(
            machineryId = machinery.id,
            machineryTitle = machinery.title,
            category = machinery.category,
            ownerName = machinery.ownerName,
            ownerPhone = machinery.ownerPhone,
            bookingDate = bookingDate,
            bookingTime = bookingTime,
            jobLocation = jobLocation,
            jobUnits = jobUnits,
            unitName = machinery.rateUnit,
            basePrice = basePrice,
            servicePrice = servicePrice,
            fuelSurcharge = fuelSurcharge,
            antigravityFee = antigravityFee,
            totalCustomerCost = totalCustomerCost,
            ownerNetEarnings = ownerNetEarnings,
            status = "PENDING",
            telematicsStatus = "Rental Request Scheduled • Operator Acknowledged • Awaiting Departure"
        )
        return bookingDao.insertBooking(booking)
    }

    suspend fun advanceBookingStatus(bookingId: Int, currentStatus: String) {
        val nextStatus = when (currentStatus.uppercase()) {
            "PENDING" -> "MOBILIZING" to "Rig en route • H3 Hex transit corridor • Speed 48 km/h"
            "CONFIRMED" -> "MOBILIZING" to "Rig en route • H3 Hex transit corridor • Speed 48 km/h"
            "MOBILIZING" -> "IN_PROGRESS" to "Operations active on site • Telematics monitoring torque & RPM"
            "ON_SITE" -> "IN_PROGRESS" to "Operations active on site • Telematics monitoring torque & RPM"
            "IN_PROGRESS" -> "COMPLETED" to "Work finalized • Escrow released directly to Owner"
            else -> "COMPLETED" to "Job Completed & Settled"
        }
        bookingDao.updateBookingStatus(bookingId, nextStatus.first, nextStatus.second)
    }

    suspend fun submitReview(
        bookingId: Int,
        rating: Int,
        comment: String,
        tags: String
    ) {
        val timestamp = System.currentTimeMillis()
        bookingDao.submitBookingReview(bookingId, rating, comment, tags, timestamp)
        
        // Also update machinery rating in DB if machinery exists
        val booking = bookingDao.getBookingById(bookingId)
        if (booking != null && booking.machineryId > 0) {
            val machine = machineryDao.getMachineryById(booking.machineryId)
            if (machine != null) {
                val newCompletedJobs = machine.completedJobs + 1
                val newRating = ((machine.ownerRating * machine.completedJobs) + rating) / newCompletedJobs
                machineryDao.update(machine.copy(
                    completedJobs = newCompletedJobs,
                    ownerRating = (Math.round(newRating * 100.0) / 100.0)
                ))
            }
        }
    }

    suspend fun createAuctionJob(
        title: String,
        category: String,
        location: String,
        details: String,
        ceilingPrice: Double
    ): Long {
        val job = AuctionJobEntity(
            title = title,
            category = category,
            location = location,
            details = details,
            ceilingPrice = ceilingPrice,
            currentLowestBid = ceilingPrice,
            bidCount = 0,
            status = "ACTIVE_BIDDING",
            expiresAtMinutes = 20
        )
        return auctionDao.insertJob(job)
    }

    suspend fun submitBid(
        jobId: Int,
        operatorName: String,
        operatorPhone: String,
        operatorRating: Double,
        equipmentTitle: String,
        bidAmount: Double,
        etaMinutes: Int,
        h3DistanceKm: Double
    ): Long {
        val bid = AuctionBidEntity(
            jobId = jobId,
            operatorName = operatorName,
            operatorPhone = operatorPhone,
            operatorRating = operatorRating,
            equipmentTitle = equipmentTitle,
            bidAmount = bidAmount,
            etaMinutes = etaMinutes,
            h3DistanceKm = h3DistanceKm
        )
        val bidId = auctionDao.insertBid(bid)
        val job = auctionDao.getJobById(jobId)
        if (job != null) {
            val newLowest = if (bidAmount < job.currentLowestBid) bidAmount else job.currentLowestBid
            auctionDao.updateJobLowestBid(jobId, newLowest)
        }
        return bidId
    }

    suspend fun acceptWinningBid(jobId: Int, bid: AuctionBidEntity) {
        auctionDao.markBidAccepted(bid.id)
        auctionDao.updateJobStatus(jobId, "AWARDED")

        // Also create a confirmed booking directly with this operator
        val subtotal = bid.bidAmount
        val antigravityFee = subtotal * 0.035
        val booking = BookingEntity(
            machineryId = 0,
            machineryTitle = bid.equipmentTitle,
            category = "Commercial Logistics",
            ownerName = bid.operatorName,
            ownerPhone = bid.operatorPhone,
            bookingDate = "Awarded via Reverse Auction",
            jobLocation = "Broadcast Location (H3 Matched)",
            jobUnits = 1.0,
            unitName = "Job Lump Sum",
            basePrice = subtotal,
            servicePrice = 0.0,
            fuelSurcharge = 0.0,
            antigravityFee = antigravityFee,
            totalCustomerCost = subtotal + antigravityFee,
            ownerNetEarnings = subtotal,
            status = "CONFIRMED",
            telematicsStatus = "Bid Locked • Mobilizing to Job Site • ETA ${bid.etaMinutes}m"
        )
        bookingDao.insertBooking(booking)
    }

    suspend fun addFleetEquipment(fleetItem: OwnerFleetEntity): Long {
        return fleetDao.insertFleet(fleetItem)
    }

    suspend fun toggleFleetOnline(fleetId: Int, isOnline: Boolean) {
        fleetDao.setFleetOnline(fleetId, isOnline)
    }
}
