package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Antigravity Industrial Modern Palette
val IndustrialAmber = Color(0xFFFF6B00)
val IndustrialAmberLight = Color(0xFFFF8A33)
val IndustrialAmberDark = Color(0xFFD95500)

val HighTechCyan = Color(0xFF00C9A7)
val HighTechCyanLight = Color(0xFF33D4B9)
val HexagonBlue = Color(0xFF3A86FF)

val SlateDark900 = Color(0xFF0A0E17)
val SlateDark800 = Color(0xFF111827)
val SlateDark700 = Color(0xFF1A2333)
val SlateDark600 = Color(0xFF273449)
val SlateBorder = Color(0xFF374151)

val TextPrimaryDark = Color(0xFFF9FAFB)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextMutedDark = Color(0xFF6B7280)

val SuccessGreen = Color(0xFF10B981)
val WarningYellow = Color(0xFFF59E0B)
val AlertRed = Color(0xFFEF4444)

// Light Palette alternatives
val SlateLight100 = Color(0xFFF8FAFC)
val SlateLight200 = Color(0xFFF1F5F9)
val SlateLight300 = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
