package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MachineryDao {
    @Query("SELECT * FROM machinery ORDER BY distanceKm ASC")
    fun getAllMachinery(): Flow<List<MachineryEntity>>

    @Query("SELECT * FROM machinery WHERE category = :category ORDER BY distanceKm ASC")
    fun getMachineryByCategory(category: String): Flow<List<MachineryEntity>>

    @Query("SELECT * FROM machinery WHERE id = :id")
    suspend fun getMachineryById(id: Int): MachineryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(machinery: List<MachineryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(machinery: MachineryEntity)

    @Update
    suspend fun update(machinery: MachineryEntity)

    @Query("SELECT COUNT(*) FROM machinery")
    suspend fun getCount(): Int
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY timestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE id = :id")
    suspend fun getBookingById(id: Int): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("UPDATE bookings SET status = :status, telematicsStatus = :telematics WHERE id = :id")
    suspend fun updateBookingStatus(id: Int, status: String, telematics: String)

    @Query("UPDATE bookings SET rating = :rating, reviewComment = :comment, reviewTags = :tags, reviewedAt = :reviewedAt WHERE id = :bookingId")
    suspend fun submitBookingReview(bookingId: Int, rating: Int, comment: String, tags: String, reviewedAt: Long)

    @Query("SELECT COUNT(*) FROM bookings")
    suspend fun getCount(): Int
}

@Dao
interface AuctionDao {
    @Query("SELECT * FROM auction_jobs ORDER BY createdAt DESC")
    fun getAllAuctionJobs(): Flow<List<AuctionJobEntity>>

    @Query("SELECT * FROM auction_jobs WHERE id = :id")
    suspend fun getJobById(id: Int): AuctionJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: AuctionJobEntity): Long

    @Update
    suspend fun updateJob(job: AuctionJobEntity)

    @Query("SELECT * FROM auction_bids WHERE jobId = :jobId ORDER BY bidAmount ASC")
    fun getBidsForJob(jobId: Int): Flow<List<AuctionBidEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBid(bid: AuctionBidEntity): Long

    @Query("UPDATE auction_bids SET isAccepted = 1 WHERE id = :bidId")
    suspend fun markBidAccepted(bidId: Int)

    @Query("UPDATE auction_jobs SET currentLowestBid = :lowestBid, bidCount = bidCount + 1 WHERE id = :jobId")
    suspend fun updateJobLowestBid(jobId: Int, lowestBid: Double)

    @Query("UPDATE auction_jobs SET status = :status WHERE id = :jobId")
    suspend fun updateJobStatus(jobId: Int, status: String)

    @Query("SELECT COUNT(*) FROM auction_jobs")
    suspend fun getJobCount(): Int
}

@Dao
interface FleetDao {
    @Query("SELECT * FROM owner_fleet ORDER BY id ASC")
    fun getAllFleet(): Flow<List<OwnerFleetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFleet(fleet: OwnerFleetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFleet(fleet: List<OwnerFleetEntity>)

    @Update
    suspend fun updateFleet(fleet: OwnerFleetEntity)

    @Query("UPDATE owner_fleet SET isOnline = :isOnline WHERE id = :id")
    suspend fun setFleetOnline(id: Int, isOnline: Boolean)

    @Query("SELECT COUNT(*) FROM owner_fleet")
    suspend fun getCount(): Int
}
