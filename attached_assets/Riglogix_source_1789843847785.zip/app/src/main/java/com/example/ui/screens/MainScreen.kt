package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.AllVehiclesVisualCatalogDialog
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.viewmodel.AntigravityViewModel
import com.example.ui.viewmodel.DisplayInterfaceMode
import com.example.ui.viewmodel.UserRole

@Composable
fun MainScreen(
    viewModel: AntigravityViewModel,
    modifier: Modifier = Modifier
) {
    val userRole by viewModel.userRole.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val auctionJobs by viewModel.auctionJobs.collectAsStateWithLifecycle()
    val displayMode by viewModel.displayMode.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }
    var showGlobalVisualGuide by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isHardwareWide = maxWidth >= 600.dp
        val isWideScreen = when (displayMode) {
            DisplayInterfaceMode.AUTO -> isHardwareWide
            DisplayInterfaceMode.PHONE -> false
            DisplayInterfaceMode.TABLET -> true
            DisplayInterfaceMode.LAPTOP -> true
        }

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBarRoleHeader(
                    userRole = userRole,
                    displayMode = displayMode,
                    onSwitchRole = { newRole ->
                        viewModel.switchRole(newRole)
                        selectedTabIndex = 0
                    },
                    onSwitchDisplayMode = { newMode ->
                        viewModel.setDisplayMode(newMode)
                    },
                    onOpenVisualGuide = {
                        showGlobalVisualGuide = true
                    }
                )
            },
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ) {
                        if (userRole == UserRole.CUSTOMER) {
                            NavigationBarItem(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                icon = { Icon(Icons.Default.Agriculture, contentDescription = "Machinery Hub") },
                                label = { Text("Hub", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_machinery_hub")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                icon = { Icon(Icons.Default.WaterDrop, contentDescription = "Borewell Drilling & Survey") },
                                label = { Text("Borewell", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_borewell_section")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                icon = {
                                    BadgedBox(badge = {
                                        if (auctionJobs.isNotEmpty()) {
                                            Badge(containerColor = IndustrialAmber) {
                                                Text("${auctionJobs.size}")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.ElectricBolt, contentDescription = "Reverse Auction")
                                    }
                                },
                                label = { Text("Auction", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_reverse_auction")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 3,
                                onClick = { selectedTabIndex = 3 },
                                icon = {
                                    BadgedBox(badge = {
                                        val activeCount = bookings.count { it.status != "COMPLETED" }
                                        if (activeCount > 0) {
                                            Badge(containerColor = HighTechCyan) {
                                                Text("$activeCount")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.Sensors, contentDescription = "H3 Radar & Telematics")
                                    }
                                },
                                label = { Text("Radar", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_spatial_radar")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 4,
                                onClick = { selectedTabIndex = 4 },
                                icon = { Icon(Icons.Default.Savings, contentDescription = "0% Broker Savings") },
                                label = { Text("Savings", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_savings")
                            )
                        } else {
                            // Owner-Operator Mode Tabs
                            NavigationBarItem(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                icon = { Icon(Icons.Default.Engineering, contentDescription = "Fleet & Earnings") },
                                label = { Text("My Fleet", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_owner_fleet")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                icon = { Icon(Icons.Default.WaterDrop, contentDescription = "Borewell Drilling Jobs") },
                                label = { Text("Borewell", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_owner_borewell")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                icon = {
                                    BadgedBox(badge = {
                                        if (auctionJobs.isNotEmpty()) {
                                            Badge(containerColor = IndustrialAmber) {
                                                Text("${auctionJobs.size}")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.ElectricBolt, contentDescription = "Bidding Floor")
                                    }
                                },
                                label = { Text("Bids Room", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_bidding_room")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 3,
                                onClick = { selectedTabIndex = 3 },
                                icon = { Icon(Icons.Default.Sensors, contentDescription = "Telematics Radar") },
                                label = { Text("Radar", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_owner_radar")
                            )
                            NavigationBarItem(
                                selected = selectedTabIndex == 4,
                                onClick = { selectedTabIndex = 4 },
                                icon = { Icon(Icons.Default.MoneyOff, contentDescription = "Zero Middlemen") },
                                label = { Text("Model", fontSize = 10.sp) },
                                colors = navItemColors(),
                                modifier = Modifier.testTag("nav_owner_model")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Wide Screen Navigation Rail for Laptop & Tablet
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("desktop_navigation_rail")
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        if (userRole == UserRole.CUSTOMER) {
                            NavigationRailItem(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                icon = { Icon(Icons.Default.Agriculture, contentDescription = "Machinery Hub") },
                                label = { Text("Hub", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_machinery_hub")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                icon = { Icon(Icons.Default.WaterDrop, contentDescription = "Borewell Drilling & Survey") },
                                label = { Text("Borewell", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_borewell_section")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                icon = {
                                    BadgedBox(badge = {
                                        if (auctionJobs.isNotEmpty()) {
                                            Badge(containerColor = IndustrialAmber) {
                                                Text("${auctionJobs.size}")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.ElectricBolt, contentDescription = "Reverse Auction")
                                    }
                                },
                                label = { Text("Auction", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_reverse_auction")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 3,
                                onClick = { selectedTabIndex = 3 },
                                icon = {
                                    BadgedBox(badge = {
                                        val activeCount = bookings.count { it.status != "COMPLETED" }
                                        if (activeCount > 0) {
                                            Badge(containerColor = HighTechCyan) {
                                                Text("$activeCount")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.Sensors, contentDescription = "H3 Radar & Telematics")
                                    }
                                },
                                label = { Text("Radar", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_spatial_radar")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 4,
                                onClick = { selectedTabIndex = 4 },
                                icon = { Icon(Icons.Default.Savings, contentDescription = "0% Broker Savings") },
                                label = { Text("Savings", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_savings")
                            )
                        } else {
                            // Owner Operator Rail Items
                            NavigationRailItem(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                icon = { Icon(Icons.Default.Engineering, contentDescription = "Fleet & Earnings") },
                                label = { Text("My Fleet", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_owner_fleet")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                icon = { Icon(Icons.Default.WaterDrop, contentDescription = "Borewell Drilling Jobs") },
                                label = { Text("Borewell", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_owner_borewell")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                icon = {
                                    BadgedBox(badge = {
                                        if (auctionJobs.isNotEmpty()) {
                                            Badge(containerColor = IndustrialAmber) {
                                                Text("${auctionJobs.size}")
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.ElectricBolt, contentDescription = "Bidding Floor")
                                    }
                                },
                                label = { Text("Bids Room", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_bidding_room")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 3,
                                onClick = { selectedTabIndex = 3 },
                                icon = { Icon(Icons.Default.Sensors, contentDescription = "Telematics Radar") },
                                label = { Text("Radar", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_owner_radar")
                            )
                            NavigationRailItem(
                                selected = selectedTabIndex == 4,
                                onClick = { selectedTabIndex = 4 },
                                icon = { Icon(Icons.Default.MoneyOff, contentDescription = "Zero Middlemen") },
                                label = { Text("Model", fontSize = 11.sp) },
                                colors = navRailItemColors(),
                                modifier = Modifier.testTag("nav_rail_owner_model")
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Crossfade(
                        targetState = userRole to selectedTabIndex,
                        label = "ScreenCrossfade"
                    ) { (role, tab) ->
                        when {
                            role == UserRole.CUSTOMER && tab == 0 -> {
                                MachineryHubScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.CUSTOMER && tab == 1 -> {
                                BorewellScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.CUSTOMER && tab == 2 -> {
                                ReverseAuctionScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.CUSTOMER && tab == 3 -> {
                                SpatialRadarScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.CUSTOMER && tab == 4 -> {
                                TransparencyScreen(isWideScreen = isWideScreen)
                            }
                            role == UserRole.OWNER_OPERATOR && tab == 0 -> {
                                OwnerPortalScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.OWNER_OPERATOR && tab == 1 -> {
                                BorewellScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.OWNER_OPERATOR && tab == 2 -> {
                                ReverseAuctionScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.OWNER_OPERATOR && tab == 3 -> {
                                SpatialRadarScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                            role == UserRole.OWNER_OPERATOR && tab == 4 -> {
                                TransparencyScreen(isWideScreen = isWideScreen)
                            }
                            else -> {
                                MachineryHubScreen(
                                    viewModel = viewModel,
                                    snackbarHostState = snackbarHostState,
                                    isWideScreen = isWideScreen
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showGlobalVisualGuide) {
            AllVehiclesVisualCatalogDialog(
                onDismiss = { showGlobalVisualGuide = false },
                onSelectVehicleType = { typeId ->
                    showGlobalVisualGuide = false
                    selectedTabIndex = 0
                    when (typeId) {
                        "borewell_rig" -> viewModel.selectCategory("Agriculture")
                        "excavator" -> viewModel.selectCategory("Construction")
                        "tipper_truck" -> viewModel.selectCategory("Logistics")
                        else -> viewModel.selectCategory("All")
                    }
                }
            )
        }
    }
}

@Composable
fun TopAppBarRoleHeader(
    userRole: UserRole,
    displayMode: DisplayInterfaceMode,
    onSwitchRole: (UserRole) -> Unit,
    onSwitchDisplayMode: (DisplayInterfaceMode) -> Unit,
    onOpenVisualGuide: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        modifier = Modifier.statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Brand Logo & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_icon),
                        contentDescription = "RigLogix Logo",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Column {
                        Text(
                            text = "RIGLOGIX",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Heavy Utility & Borewell Aggregator",
                            fontSize = 9.sp,
                            color = HighTechCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Action Controls: Vehicle Guide, Interface Switcher & Role Selector
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Visual Vehicle Guide Button
                    Surface(
                        color = IndustrialAmber.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .border(
                                1.dp,
                                IndustrialAmber.copy(alpha = 0.4f),
                                RoundedCornerShape(20.dp)
                            )
                            .clickable { onOpenVisualGuide() }
                            .testTag("topbar_vehicle_visual_guide_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Visibility,
                                contentDescription = "Visual Vehicle Guide",
                                modifier = Modifier.size(14.dp),
                                tint = IndustrialAmber
                            )
                            Text(
                                text = "Vehicles",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndustrialAmber
                            )
                        }
                    }

                    // Display Interface Switcher Dropdown
                    DisplayModeSelector(
                        currentMode = displayMode,
                        onSelectMode = onSwitchDisplayMode
                    )

                    // Dual Persona Selector Pill
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            RoundedCornerShape(20.dp)
                        )
                    ) {
                        Row(modifier = Modifier.padding(3.dp)) {
                            RoleSelectorChip(
                                title = "Client",
                                isSelected = userRole == UserRole.CUSTOMER,
                                onClick = { onSwitchRole(UserRole.CUSTOMER) },
                                testTag = "role_chip_customer"
                            )
                            RoleSelectorChip(
                                title = "Operator",
                                isSelected = userRole == UserRole.OWNER_OPERATOR,
                                onClick = { onSwitchRole(UserRole.OWNER_OPERATOR) },
                                testTag = "role_chip_operator"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DisplayModeSelector(
    currentMode: DisplayInterfaceMode,
    onSelectMode: (DisplayInterfaceMode) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val icon = when (currentMode) {
        DisplayInterfaceMode.AUTO -> Icons.Default.Devices
        DisplayInterfaceMode.PHONE -> Icons.Default.PhoneAndroid
        DisplayInterfaceMode.TABLET -> Icons.Default.Tablet
        DisplayInterfaceMode.LAPTOP -> Icons.Default.Laptop
    }

    Box {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    RoundedCornerShape(20.dp)
                )
                .clickable { expanded = true }
                .testTag("display_mode_selector_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    icon,
                    contentDescription = "Interface Mode",
                    modifier = Modifier.size(15.dp),
                    tint = HighTechCyan
                )
                Text(
                    text = currentMode.shortLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DisplayInterfaceMode.values().forEach { mode ->
                val modeIcon = when (mode) {
                    DisplayInterfaceMode.AUTO -> Icons.Default.Devices
                    DisplayInterfaceMode.PHONE -> Icons.Default.PhoneAndroid
                    DisplayInterfaceMode.TABLET -> Icons.Default.Tablet
                    DisplayInterfaceMode.LAPTOP -> Icons.Default.Laptop
                }
                DropdownMenuItem(
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                modeIcon,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = if (mode == currentMode) IndustrialAmber else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = mode.label,
                                fontWeight = if (mode == currentMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (mode == currentMode) IndustrialAmber else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    onClick = {
                        onSelectMode(mode)
                        expanded = false
                    },
                    modifier = Modifier.testTag("display_mode_option_${mode.name.lowercase()}")
                )
            }
        }
    }
}

@Composable
fun RoleSelectorChip(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        color = if (isSelected) IndustrialAmber else Color.Transparent,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = IndustrialAmber,
    selectedTextColor = IndustrialAmber,
    indicatorColor = IndustrialAmber.copy(alpha = 0.15f),
    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
)

@Composable
fun navRailItemColors() = NavigationRailItemDefaults.colors(
    selectedIconColor = IndustrialAmber,
    selectedTextColor = IndustrialAmber,
    indicatorColor = IndustrialAmber.copy(alpha = 0.15f),
    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
)

