package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.MachineryEntity
import com.example.ui.components.VehicleStructureExplainerDialog
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AntigravityViewModel
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BorewellScreen(
    viewModel: AntigravityViewModel,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
    isWideScreen: Boolean = false
) {
    val machineryList by viewModel.allMachinery.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    val inrFormatter = remember {
        NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
            maximumFractionDigits = 0
        }
    }

    // Filter borewell rigs specifically
    val borewellRigs = machineryList.filter {
        it.subCategory.contains("Borewell", ignoreCase = true) ||
        it.title.contains("Borewell", ignoreCase = true)
    }

    // Active borewell bookings
    val activeBorewellBookings = bookings.filter {
        it.machineryTitle.contains("Borewell", ignoreCase = true) ||
        it.category.equals("Agriculture", ignoreCase = true)
    }

    // Interactive Cost Estimator State
    var targetDepthFeet by remember { mutableFloatStateOf(850f) }
    var casingDepthFeet by remember { mutableFloatStateOf(80f) }
    var selectedGeology by remember { mutableStateOf("Hard Granite / Blue Basalt (DTH Rig)") }
    var selectedCasingType by remember { mutableStateOf("6.5\" Heavy Duty PVC (10 kg/cm²)") }

    val drillingRatePerFt = when (selectedGeology) {
        "Soft Soil / Red Earth" -> 85.0
        "Sandy Alluvium (Rotary Mud Rig)" -> 110.0
        else -> 95.0 // Hard Granite
    }

    val casingRatePerFt = when (selectedCasingType) {
        "7\" M.S. Steel Heavy Casing" -> 620.0
        "Slotted PVC Sand Screen" -> 420.0
        else -> 360.0 // 6.5" PVC
    }

    val baseMobilization = 7500.0
    val airFlushingAndCap = 2500.0
    val estDrillingCost = targetDepthFeet * drillingRatePerFt
    val estCasingCost = casingDepthFeet * casingRatePerFt
    val subtotal = baseMobilization + estDrillingCost + estCasingCost + airFlushingAndCap
    val platformFee = subtotal * 0.035
    val totalEstimatedCost = subtotal + platformFee
    val brokerMarkup = subtotal * 0.30
    val farmerSavings = brokerMarkup - platformFee

    var showBookingDialogFor by remember { mutableStateOf<MachineryEntity?>(null) }
    var showGroundwaterSurveyDialog by remember { mutableStateOf(false) }
    var structureExplainerFor by remember { mutableStateOf<MachineryEntity?>(null) }

    if (!isWideScreen) {
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .testTag("borewell_screen_view"),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Hero Header Card for Borewell Utility
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = HighTechCyan,
                            shape = CircleShape,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.WaterDrop,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Borewell Drilling & Groundwater Hub",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Direct-to-Rig Owner • 0% Broker Commission • 100% Transparent Rates",
                                fontSize = 11.sp,
                                color = HighTechCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Book high-pressure DTH drilling rigs (1200 CFM/350 PSI), rotary mud rigs, and certified hydrogeological water point scanning directly from verified local rig operators.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showGroundwaterSurveyDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = HighTechCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Science, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Water Point Survey", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                if (borewellRigs.isNotEmpty()) {
                                    showBookingDialogFor = borewellRigs.first()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Instant Rig Mobilize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Visual Rig Anatomy Card for non-technical customers
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        structureExplainerFor = borewellRigs.firstOrNull() ?: machineryList.first()
                    }
                    .testTag("borewell_visual_rig_guide_banner"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(64.dp)
                    ) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_borewell_rig),
                            contentDescription = "Borewell Rig Anatomy",
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Borewell Rig Anatomy Guide", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                color = IndustrialAmber.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "No Jargon",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IndustrialAmber,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            "See picture, structure & how the air compressor and hammer bit drill deep without getting confused by technical specs.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp,
                            maxLines = 2
                        )
                    }
                    Icon(
                        Icons.Default.Visibility,
                        contentDescription = "View Guide",
                        tint = HighTechCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Live Active Borewell Telemetry Card
        if (activeBorewellBookings.isNotEmpty()) {
            item {
                Text(
                    text = "Live Active Borewell Operations",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(activeBorewellBookings, key = { it.id }) { booking ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(HighTechCyan))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                Text(
                                    text = booking.machineryTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = IndustrialAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = booking.status,
                                    color = IndustrialAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Site: ${booking.jobLocation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Compress, contentDescription = null, tint = HighTechCyan, modifier = Modifier.size(18.dp))
                                Text(
                                    text = booking.telematicsStatus,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HighTechCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Contract Value: ${inrFormatter.format(booking.totalCustomerCost)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = {
                                    viewModel.advanceBooking(booking.id, booking.status)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Next Drilling Stage", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Interactive Borewell Cost & Depth Estimator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Plumbing, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Borewell Cost Estimator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = SuccessGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "MARKET RATES (INR ₹)",
                                color = SuccessGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Target Depth Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Target Drilling Depth",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${targetDepthFeet.toInt()} Feet",
                            fontWeight = FontWeight.Bold,
                            color = HighTechCyan
                        )
                    }
                    Slider(
                        value = targetDepthFeet,
                        onValueChange = { targetDepthFeet = it },
                        valueRange = 300f..1500f,
                        steps = 23,
                        colors = SliderDefaults.colors(
                            thumbColor = HighTechCyan,
                            activeTrackColor = HighTechCyan,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    // Casing Depth Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Casing Pipe Depth (to Bedrock)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${casingDepthFeet.toInt()} Feet",
                            fontWeight = FontWeight.Bold,
                            color = IndustrialAmber
                        )
                    }
                    Slider(
                        value = casingDepthFeet,
                        onValueChange = { casingDepthFeet = it },
                        valueRange = 40f..200f,
                        steps = 15,
                        colors = SliderDefaults.colors(
                            thumbColor = IndustrialAmber,
                            activeTrackColor = IndustrialAmber,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Geological Formation Selector
                    Text(
                        text = "Geological Terrain",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    GeologySelectorRow(
                        options = listOf(
                            "Hard Granite / Blue Basalt (DTH Rig)" to "₹95/ft",
                            "Sandy Alluvium (Rotary Mud Rig)" to "₹110/ft",
                            "Soft Soil / Red Earth" to "₹85/ft"
                        ),
                        selected = selectedGeology,
                        onSelect = { selectedGeology = it }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Casing Type Selector
                    Text(
                        text = "Casing Pipe Specification",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    GeologySelectorRow(
                        options = listOf(
                            "6.5\" Heavy Duty PVC (10 kg/cm²)" to "₹360/ft",
                            "7\" M.S. Steel Heavy Casing" to "₹620/ft",
                            "Slotted PVC Sand Screen" to "₹420/ft"
                        ),
                        selected = selectedCasingType,
                        onSelect = { selectedCasingType = it }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Calculation Breakdown Box
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Transparent Upfront Price Breakdown",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = HighTechCyan
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            PriceRow("Base Rig Mobilization & Hydraulic Setup", inrFormatter.format(baseMobilization))
                            PriceRow("Drilling (${targetDepthFeet.toInt()} ft @ ₹${drillingRatePerFt.toInt()}/ft)", inrFormatter.format(estDrillingCost))
                            PriceRow("Casing Pipe (${casingDepthFeet.toInt()} ft @ ₹${casingRatePerFt.toInt()}/ft)", inrFormatter.format(estCasingCost))
                            PriceRow("Compressor Air Flushing & Heavy Well Cap", inrFormatter.format(airFlushingAndCap))
                            PriceRow("RigLogix Flat Platform Fee (3.5%)", inrFormatter.format(platformFee))

                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Estimated Cost", fontWeight = FontWeight.Bold)
                                Text(
                                    text = inrFormatter.format(totalEstimatedCost),
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 16.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = SuccessGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Estimated Farmer Savings: ${inrFormatter.format(farmerSavings)} vs local broker cut (30%)",
                                    color = SuccessGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val rigToBook = borewellRigs.firstOrNull() ?: machineryList.first()
                            showBookingDialogFor = rigToBook
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("book_calculated_borewell_button")
                    ) {
                        Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Book Rig for This Estimate (${targetDepthFeet.toInt()} ft)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Available Verified Borewell Rigs Nearby
        item {
            Text(
                text = "Nearby Verified Borewell Rigs (${borewellRigs.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(borewellRigs, key = { it.id }) { rig ->
            MachineryCard(
                machinery = rig,
                onBookClick = { showBookingDialogFor = rig },
                onDetailsClick = { viewModel.selectMachinery(rig) },
                onCallClick = {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:${rig.ownerPhone}")
                    }
                    context.startActivity(intent)
                },
                onOpenStructureExplainer = {
                    structureExplainerFor = rig
                }
            )
        }
    }
    } else {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column: Hero Banner + Depth & Strata Estimator
            LazyColumn(
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // Hero Header Card for Borewell Utility
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = HighTechCyan,
                                    shape = CircleShape,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.WaterDrop,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Borewell Drilling & Groundwater Hub",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Direct-to-Rig Owner • 0% Broker Commission • 100% Transparent Rates",
                                        fontSize = 11.sp,
                                        color = HighTechCyan,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Book high-pressure DTH drilling rigs (1200 CFM/350 PSI), rotary mud rigs, and certified hydrogeological water point scanning directly from verified local rig operators.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { showGroundwaterSurveyDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = HighTechCyan),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Science, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Water Point Survey", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        if (borewellRigs.isNotEmpty()) {
                                            showBookingDialogFor = borewellRigs.first()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Instant Rig Mobilize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Interactive Borewell Cost & Depth Estimator
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.Plumbing, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "Borewell Cost Estimator",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Surface(
                                    color = SuccessGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "MARKET RATES (INR ₹)",
                                        color = SuccessGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Target Depth Slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Target Drilling Depth",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${targetDepthFeet.toInt()} Feet",
                                    fontWeight = FontWeight.Bold,
                                    color = HighTechCyan
                                )
                            }
                            Slider(
                                value = targetDepthFeet,
                                onValueChange = { targetDepthFeet = it },
                                valueRange = 300f..1500f,
                                steps = 23,
                                colors = SliderDefaults.colors(
                                    thumbColor = HighTechCyan,
                                    activeTrackColor = HighTechCyan,
                                    inactiveTrackColor = MaterialTheme.colorScheme.outline
                                )
                            )

                            // Casing Depth Slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Casing Pipe Depth (to Bedrock)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${casingDepthFeet.toInt()} Feet",
                                    fontWeight = FontWeight.Bold,
                                    color = IndustrialAmber
                                )
                            }
                            Slider(
                                value = casingDepthFeet,
                                onValueChange = { casingDepthFeet = it },
                                valueRange = 40f..200f,
                                steps = 15,
                                colors = SliderDefaults.colors(
                                    thumbColor = IndustrialAmber,
                                    activeTrackColor = IndustrialAmber,
                                    inactiveTrackColor = MaterialTheme.colorScheme.outline
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Geological Formation Selector
                            Text(
                                text = "Geological Terrain",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                GeologyOptionChip(
                                    name = "Hard Granite / Basalt",
                                    rate = "₹95/ft",
                                    isSelected = selectedGeology.contains("Granite"),
                                    onClick = { selectedGeology = "Hard Granite / Blue Basalt (DTH Rig)" },
                                    modifier = Modifier.weight(1f)
                                )
                                GeologyOptionChip(
                                    name = "Soft Soil / Red Earth",
                                    rate = "₹85/ft",
                                    isSelected = selectedGeology.contains("Soft Soil"),
                                    onClick = { selectedGeology = "Soft Soil / Red Earth" },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            GeologyOptionChip(
                                name = "Sandy Alluvium (Mud Rig)",
                                rate = "₹110/ft",
                                isSelected = selectedGeology.contains("Sandy Alluvium"),
                                onClick = { selectedGeology = "Sandy Alluvium (Rotary Mud Rig)" },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Casing Pipe Type Selector
                            Text(
                                text = "Casing Pipe Specification",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                GeologyOptionChip(
                                    name = "6.5\" Heavy PVC",
                                    rate = "₹360/ft",
                                    isSelected = selectedCasingType.contains("6.5\""),
                                    onClick = { selectedCasingType = "6.5\" Heavy Duty PVC (10 kg/cm²)" },
                                    modifier = Modifier.weight(1f)
                                )
                                GeologyOptionChip(
                                    name = "7\" M.S. Steel Casing",
                                    rate = "₹620/ft",
                                    isSelected = selectedCasingType.contains("7\" M.S."),
                                    onClick = { selectedCasingType = "7\" M.S. Steel Heavy Casing" },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Live Cost Breakdown
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "TRANSPARENT DRILLING QUOTE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = HighTechCyan,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))

                                    PriceRow("Base Rig Mobilization & Hydraulic Setup", inrFormatter.format(baseMobilization))
                                    PriceRow("Drilling (${targetDepthFeet.toInt()} ft @ ₹${drillingRatePerFt.toInt()}/ft)", inrFormatter.format(estDrillingCost))
                                    PriceRow("Casing Pipe (${casingDepthFeet.toInt()} ft @ ₹${casingRatePerFt.toInt()}/ft)", inrFormatter.format(estCasingCost))
                                    PriceRow("Compressor Air Flushing & Heavy Well Cap", inrFormatter.format(airFlushingAndCap))
                                    PriceRow("RigLogix Flat Platform Fee (3.5%)", inrFormatter.format(platformFee))

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Total Estimated Cost", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = inrFormatter.format(totalEstimatedCost),
                                            fontWeight = FontWeight.Black,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 16.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Surface(
                                        color = SuccessGreen.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Estimated Farmer Savings: ${inrFormatter.format(farmerSavings)} vs local broker cut (30%)",
                                            color = SuccessGreen,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(8.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    val rigToBook = borewellRigs.firstOrNull() ?: machineryList.first()
                                    showBookingDialogFor = rigToBook
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("book_calculated_borewell_button_wide")
                            ) {
                                Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Book Rig for This Estimate (${targetDepthFeet.toInt()} ft)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Right Column: Active Operations + Nearby Verified Borewell Rigs
            LazyColumn(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (activeBorewellBookings.isNotEmpty()) {
                    item {
                        Text(
                            text = "Live Active Borewell Operations (${activeBorewellBookings.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(activeBorewellBookings, key = { it.id }) { booking ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(HighTechCyan))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = booking.machineryTitle,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Surface(
                                        color = IndustrialAmber.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = booking.status,
                                            color = IndustrialAmber,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Site: ${booking.jobLocation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.Compress, contentDescription = null, tint = HighTechCyan, modifier = Modifier.size(18.dp))
                                        Text(
                                            text = booking.telematicsStatus,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = HighTechCyan
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Contract Value: ${inrFormatter.format(booking.totalCustomerCost)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.advanceBooking(booking.id, booking.status)
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Next Drilling Stage", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Nearby Verified Borewell Rigs (${borewellRigs.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(borewellRigs, key = { it.id }) { rig ->
                    MachineryCard(
                        machinery = rig,
                        onBookClick = { showBookingDialogFor = rig },
                        onDetailsClick = { viewModel.selectMachinery(rig) },
                        onCallClick = {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${rig.ownerPhone}")
                            }
                            context.startActivity(intent)
                        },
                        onOpenStructureExplainer = {
                            structureExplainerFor = rig
                        }
                    )
                }
            }
        }
    }

    // Vehicle Structure Explainer Dialog for non-technical customers
    if (structureExplainerFor != null) {
        VehicleStructureExplainerDialog(
            machinery = structureExplainerFor!!,
            onDismiss = { structureExplainerFor = null }
        )
    }

    // Direct Booking Dialog for Borewell
    showBookingDialogFor?.let { rig ->
        DirectBookingDialog(
            machinery = rig,
            onDismiss = { showBookingDialogFor = null },
            onConfirm = { location, units ->
                viewModel.createBooking(
                    machinery = rig,
                    jobLocation = location,
                    jobUnits = units
                ) {
                    showBookingDialogFor = null
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(
                            "Borewell Rig Mobilized! Dispatched to $location."
                        )
                    }
                }
            }
        )
    }

    // Groundwater Survey Dialog
    if (showGroundwaterSurveyDialog) {
        AlertDialog(
            onDismissRequest = { showGroundwaterSurveyDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Science, contentDescription = null, tint = HighTechCyan)
                    Text("Scientific Water Point Survey", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Book a certified Hydrogeologist with high-precision Vertical Electrical Resistivity (VES) and electromagnetic sensors before drilling.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("• Deep Aquifer & Water Table Depth Detection", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("• Bedrock Fracture & Fault Line Identification", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("• Recommended Casing & Drilling Depth Report", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Fixed Survey Fee: ₹3,500 per survey point", color = HighTechCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showGroundwaterSurveyDialog = false
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Hydrogeologist dispatched for Water Point Survey (Hex #8828308281ff)!")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HighTechCyan)
                ) {
                    Text("Book Survey (₹3,500)", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGroundwaterSurveyDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun GeologySelectorRow(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (name, rate) ->
            val isSelected = name == selected
            Surface(
                color = if (isSelected) IndustrialAmber.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = if (isSelected) {
                    androidx.compose.foundation.BorderStroke(1.dp, IndustrialAmber)
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(name) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = name,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) IndustrialAmber else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = rate,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) HighTechCyan else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun GeologyOptionChip(
    name: String,
    rate: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isSelected) IndustrialAmber.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = if (isSelected) {
            androidx.compose.foundation.BorderStroke(1.dp, IndustrialAmber)
        } else {
            androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        },
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = name,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) IndustrialAmber else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Text(
                text = rate,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) HighTechCyan else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
