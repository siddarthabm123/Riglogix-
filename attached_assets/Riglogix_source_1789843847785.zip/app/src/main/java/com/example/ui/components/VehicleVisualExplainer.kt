package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.MachineryEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen

/**
 * Data structures designed for everyday customers (farmers, landowners, home builders)
 * who do NOT know heavy machinery jargon.
 */
data class VehicleStructurePart(
    val partNumber: Int,
    val partName: String,
    val everydayName: String,
    val plainDescription: String,
    val icon: ImageVector
)

data class VehicleCustomerGuide(
    val typeId: String,
    val vehicleDisplayName: String,
    val imageResId: Int,
    val plainPurposeHeadline: String,
    val whoNeedsThis: String,
    val whatItLooksLike: String,
    val capacityInSimpleWords: String,
    val structureParts: List<VehicleStructurePart>,
    val jargonBuster: List<Pair<String, String>>
)

object VehicleVisualRepository {

    val borewellRigGuide = VehicleCustomerGuide(
        typeId = "borewell_rig",
        vehicleDisplayName = "Water Borewell Drilling Rig Truck",
        imageResId = R.drawable.img_borewell_rig,
        plainPurposeHeadline = "Drills deep underground holes into soil & solid granite rock to find fresh drinking/irrigation water.",
        whoNeedsThis = "Farmers needing crop irrigation, or landowners building a house where municipal water is unavailable.",
        whatItLooksLike = "A heavy commercial multi-axle truck with a massive vertical steel tower (mast) that stands up to drill into the earth.",
        capacityInSimpleWords = "Drills from 300 ft up to 1,500 ft deep. Can penetrate solid rock in less than 24 hours.",
        structureParts = listOf(
            VehicleStructurePart(
                partNumber = 1,
                partName = "Vertical Drilling Mast",
                everydayName = "Tall Steel Tower",
                plainDescription = "The tall metal structure that raises upright to lower and spin long steel drill rods into the ground.",
                icon = Icons.Default.Construction
            ),
            VehicleStructurePart(
                partNumber = 2,
                partName = "Pneumatic Air Compressor",
                everydayName = "Super-Pressure Air Jet",
                plainDescription = "Pumps tremendous air pressure (350 PSI) to blow crushed rock and dust out of the hole while drilling.",
                icon = Icons.Default.Compress
            ),
            VehicleStructurePart(
                partNumber = 3,
                partName = "DTH Tungsten Button Bit",
                everydayName = "Heavy Rock Hammer",
                plainDescription = "Pneumatic hammer bit with ultra-hard tungsten carbide buttons that smashes through tough granite rocks.",
                icon = Icons.Default.Engineering
            ),
            VehicleStructurePart(
                partNumber = 4,
                partName = "Hydraulic Leveling Outriggers",
                everydayName = "Stabilizer Lift Jacks",
                plainDescription = "4 heavy hydraulic legs that lift the entire truck off the ground to keep it 100% stable on uneven farm terrain.",
                icon = Icons.Default.Security
            )
        ),
        jargonBuster = listOf(
            "What does DTH mean?" to "Down-The-Hole: The pneumatic hammer strikes rock directly at the bottom of the hole for maximum crushing power.",
            "What is 1200 CFM / 350 PSI?" to "High-volume compressed air that flushes water, mud, and crushed gravel straight out of the hole without needing slurry pumps.",
            "What is a Casing Pipe?" to "A strong outer PVC or steel pipe placed in the top 50-120 ft to prevent surface dirt and sand from collapsing into your clean well."
        )
    )

    val excavatorGuide = VehicleCustomerGuide(
        typeId = "excavator",
        vehicleDisplayName = "Hydraulic Heavy Excavator (Earthmover)",
        imageResId = R.drawable.img_heavy_excavator,
        plainPurposeHeadline = "Digs deep foundation pits, trenches, drainage channels, pond desilting, and breaks rocky ground.",
        whoNeedsThis = "Anyone building a house foundation, digging farm ponds/wells, clearing rocky land, or laying pipes.",
        whatItLooksLike = "A powerful heavy machine on continuous steel tracks with an articulated hydraulic arm and a steel tooth bucket.",
        capacityInSimpleWords = "Can dig 15 to 20 feet deep and scoop 1 to 2 tons of dirt in every single scoop.",
        structureParts = listOf(
            VehicleStructurePart(
                partNumber = 1,
                partName = "Articulated Boom & Arm",
                everydayName = "Hydraulic Digging Arm",
                plainDescription = "Two-jointed heavy steel arm powered by hydraulic cylinders to reach deep into pits and trenches.",
                icon = Icons.Default.Construction
            ),
            VehicleStructurePart(
                partNumber = 2,
                partName = "Heavy Digging Bucket / Rock Breaker",
                everydayName = "Toothed Scoop / Hammer",
                plainDescription = "Heavy steel bucket with sharp teeth to dig soil, or can be swapped with a hydraulic breaker to crack boulders.",
                icon = Icons.Default.Engineering
            ),
            VehicleStructurePart(
                partNumber = 3,
                partName = "Steel Crawler Tracks",
                everydayName = "Tank-Style Mud Tracks",
                plainDescription = "Heavy metal tracks that let the excavator drive through deep mud, soft farmland, and steep slopes without sinking.",
                icon = Icons.Default.Speed
            ),
            VehicleStructurePart(
                partNumber = 4,
                partName = "360° Rotating House",
                everydayName = "Full Spin Operator Cabin",
                plainDescription = "The cabin rotates in a complete circle so the driver can scoop earth in front and dump it into a truck behind.",
                icon = Icons.Default.Security
            )
        ),
        jargonBuster = listOf(
            "What is an Earthmover / JCB?" to "Common terms for excavators and backhoe loaders used for heavy earth-digging and site clearing.",
            "Bucket Capacity (e.g. 1.1 m³)?" to "Means each scoop can pick up approximately 1.5 to 2 tons of earth or loose rock.",
            "Crawler vs Wheeled?" to "Crawler tracks excel in rough mud and soft soil, while wheeled loaders drive faster on paved roads."
        )
    )

    val tipperTruckGuide = VehicleCustomerGuide(
        typeId = "tipper_truck",
        vehicleDisplayName = "Multi-Axle Heavy Tipper (Dump Truck)",
        imageResId = R.drawable.img_tipper_truck,
        plainPurposeHeadline = "Transports large loads of sand, gravel, stone, construction debris, or harvested crops and dumps them automatically.",
        whoNeedsThis = "Anyone needing bulk construction materials delivered (sand, aggregate stone) or waste earth hauled away.",
        whatItLooksLike = "A large 10-wheeler or 12-wheeler heavy commercial truck with a reinforced steel box bed that tilts up to slide cargo out.",
        capacityInSimpleWords = "Carries 16 to 25 metric tons per trip (equivalent to 3 to 4 tractor trolleys in one load).",
        structureParts = listOf(
            VehicleStructurePart(
                partNumber = 1,
                partName = "Hydraulic Tipping Piston",
                everydayName = "Bed Lift Ram",
                plainDescription = "A strong hydraulic cylinder under the bed that raises the front of the box to slide all sand/gravel out in seconds.",
                icon = Icons.Default.Engineering
            ),
            VehicleStructurePart(
                partNumber = 2,
                partName = "Reinforced Steel Dump Bed",
                everydayName = "Heavy Cargo Box",
                plainDescription = "Tough high-tensile steel container with automatic swing tailgate designed to withstand jagged rocks and boulders.",
                icon = Icons.Default.LocalShipping
            ),
            VehicleStructurePart(
                partNumber = 3,
                partName = "Multi-Axle Heavy Chassis",
                everydayName = "10 to 14 Heavy Wheels",
                plainDescription = "Multiple wheel axles that spread the huge weight evenly to prevent breaking roads and sinking in soft dirt.",
                icon = Icons.Default.Speed
            ),
            VehicleStructurePart(
                partNumber = 4,
                partName = "Commercial Driver Cabin",
                everydayName = "Heavy Vehicle Driver Cab",
                plainDescription = "High-visibility cabin equipped with GPS telematics tracking and power steering for tight site access.",
                icon = Icons.Default.Security
            )
        ),
        jargonBuster = listOf(
            "What is a Tipper vs Lorry?" to "A regular lorry has a flat bed where men must manually shovel cargo. A tipper tilts up hydraulically to dump cargo automatically.",
            "Payload Tonnage (e.g. 20 Ton)?" to "Maximum safe weight of materials the truck can legally carry on public roads.",
            "Why direct booking?" to "Booking direct saves up to 30% broker fees and gives direct phone contact with the owner-driver."
        )
    )

    val farmMachineryGuide = VehicleCustomerGuide(
        typeId = "farm_machinery",
        vehicleDisplayName = "Agricultural Harvester & Field Tractor",
        imageResId = R.drawable.img_hero_machinery,
        plainPurposeHeadline = "Cuts, threshes, and cleans paddy, wheat, corn or plows and levels farm acreage in rapid time.",
        whoNeedsThis = "Farmers wanting quick, automated crop harvesting or soil tilling without relying on scarce manual labor.",
        whatItLooksLike = "High-clearance agricultural machinery with rotating cutter bar, grain storage tank, and large flotation tyres.",
        capacityInSimpleWords = "Harvests 1.5 to 2.5 acres of farm crop per hour and separates grain cleanly.",
        structureParts = listOf(
            VehicleStructurePart(
                partNumber = 1,
                partName = "Revolving Cutter Bar & Reel",
                everydayName = "Crop Cutter Header",
                plainDescription = "Wide cutting knives that gently pull standing crops, cut stems cleanly, and feed them into the thresher.",
                icon = Icons.Default.Agriculture
            ),
            VehicleStructurePart(
                partNumber = 2,
                partName = "Internal Threshing Drum",
                everydayName = "Grain Separator",
                plainDescription = "Spins at high speed to separate clean grains from husk, stalks, and chaff cleanly.",
                icon = Icons.Default.Construction
            ),
            VehicleStructurePart(
                partNumber = 3,
                partName = "Grain Tank & Unload Auger",
                everydayName = "Clean Grain Pipe",
                plainDescription = "Stores harvested grain and unloads it through a high-reach pipe directly into waiting farm trailers.",
                icon = Icons.Default.WaterDrop
            ),
            VehicleStructurePart(
                partNumber = 4,
                partName = "High-Lug Farm Tyres",
                everydayName = "Deep Tread Field Wheels",
                plainDescription = "Extra wide tires that disperse weight so the heavy machine glides through wet paddy mud without compacting soil.",
                icon = Icons.Default.Speed
            )
        ),
        jargonBuster = listOf(
            "What is a Combine Harvester?" to "Combines 3 operations in 1 pass: cutting crop, threshing grain, and cleaning husk automatically.",
            "Low Compaction?" to "Prevents crushing the root zone of the soil so next season's crop grows vigorously.",
            "Direct Hourly Rate?" to "Pay only for running field meter hours with no hidden middleman cuts."
        )
    )

    fun getGuideForMachinery(machinery: MachineryEntity): VehicleCustomerGuide {
        val title = machinery.title.lowercase()
        val sub = machinery.subCategory.lowercase()
        val cat = machinery.category.lowercase()

        return when {
            sub.contains("borewell") || title.contains("borewell") || title.contains("rig") -> borewellRigGuide
            sub.contains("excavator") || sub.contains("backhoe") || title.contains("jcb") || title.contains("cat") -> excavatorGuide
            sub.contains("lorry") || sub.contains("tipper") || sub.contains("trailer") || cat.contains("logistics") -> tipperTruckGuide
            sub.contains("harvester") || sub.contains("tractor") || cat.contains("agriculture") -> farmMachineryGuide
            else -> excavatorGuide
        }
    }

    val allGuides = listOf(borewellRigGuide, excavatorGuide, tipperTruckGuide, farmMachineryGuide)
}

/**
 * Visual vehicle picture banner with quick badge & "Structure" button
 */
@Composable
fun VehiclePictureCard(
    machinery: MachineryEntity,
    onOpenStructureExplainer: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val guide = VehicleVisualRepository.getGuideForMachinery(machinery)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onOpenStructureExplainer() }
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = guide.imageResId),
                contentDescription = guide.vehicleDisplayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 8.5f)
                    .clip(RoundedCornerShape(12.dp))
            )

            // Dark gradient overlay on bottom for readability
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.82f))
                        )
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = IndustrialAmber,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = guide.vehicleDisplayName.uppercase(),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = guide.whatItLooksLike,
                            fontSize = 11.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                    }

                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, HighTechCyan)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Visibility,
                                contentDescription = "See Structure",
                                tint = HighTechCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Structure",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = HighTechCyan
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Plain-English explanation banner that replaces or simplifies long walls of technical jargon
 */
@Composable
fun VehiclePlainEnglishBadge(
    machinery: MachineryEntity,
    onSeeDetails: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val guide = VehicleVisualRepository.getGuideForMachinery(machinery)

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Default.Lightbulb,
                    contentDescription = null,
                    tint = IndustrialAmber,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "WHAT IS THIS FOR? (IN SIMPLE WORDS)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndustrialAmber,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = guide.plainPurposeHeadline,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚡ ${guide.capacityInSimpleWords}",
                    fontSize = 11.sp,
                    color = HighTechCyan,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = onSeeDetails,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("See Structure", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndustrialAmber)
                }
            }
        }
    }
}

/**
 * Interactive Dialog showing the vehicle picture, visual structure breakdown,
 * plain English guide, and Jargon Buster.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VehicleStructureExplainerDialog(
    machinery: MachineryEntity,
    onDismiss: () -> Unit,
    onBookClick: () -> Unit = {}
) {
    val guide = VehicleVisualRepository.getGuideForMachinery(machinery)
    var selectedSection by remember { mutableIntStateOf(0) } // 0: Structure, 1: Plain English, 2: Jargon Buster

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = guide.vehicleDisplayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Visual Customer Guide • No Confusing Technical Jargon",
                            fontSize = 11.sp,
                            color = HighTechCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // High quality vehicle image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Image(
                        painter = painterResource(id = guide.imageResId),
                        contentDescription = guide.vehicleDisplayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                    )
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(topStart = 8.dp),
                        modifier = Modifier.align(Alignment.BottomEnd)
                    ) {
                        Text(
                            text = "REAL VEHICLE PROFILE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tab Switcher for Structure / Guide / Jargon Buster
                TabRow(
                    selectedTabIndex = selectedSection,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = IndustrialAmber,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                            color = IndustrialAmber
                        )
                    }
                ) {
                    Tab(
                        selected = selectedSection == 0,
                        onClick = { selectedSection = 0 },
                        text = { Text("Vehicle Structure", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedSection == 1,
                        onClick = { selectedSection = 1 },
                        text = { Text("How It Works", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedSection == 2,
                        onClick = { selectedSection = 2 },
                        text = { Text("Jargon Buster", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable tab content
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (selectedSection) {
                        0 -> {
                            item {
                                Text(
                                    text = "Key Vehicle Components (In Plain English):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            items(guide.structureParts) { part ->
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Surface(
                                            color = IndustrialAmber.copy(alpha = 0.15f),
                                            shape = CircleShape,
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${part.partNumber}",
                                                    fontWeight = FontWeight.Black,
                                                    color = IndustrialAmber,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = part.everydayName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "(${part.partName})",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = part.plainDescription,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        1 -> {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "🎯 Main Purpose:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = HighTechCyan
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = guide.plainPurposeHeadline,
                                            fontSize = 12.sp
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "👨‍🌾 Who Needs This Vehicle?",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = SuccessGreen
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = guide.whoNeedsThis,
                                            fontSize = 12.sp
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "⚡ Practical Capacity:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = IndustrialAmber
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = guide.capacityInSimpleWords,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                        2 -> {
                            items(guide.jargonBuster) { (term, explanation) ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Info,
                                                contentDescription = null,
                                                tint = IndustrialAmber,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = term,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = explanation,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onBookClick()
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Book This Vehicle Directly", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Close Guide")
            }
        }
    )
}

/**
 * Full Visual Vehicle Guide dialog showing all vehicle types side-by-side
 * for customers exploring what kind of machine they need.
 */
@Composable
fun AllVehiclesVisualCatalogDialog(
    onDismiss: () -> Unit,
    onSelectVehicleType: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val guides = VehicleVisualRepository.allGuides
    val activeGuide = guides.getOrNull(selectedTab) ?: guides.first()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Visual Heavy Vehicle Guide",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Find the exact vehicle you need with real pictures & plain words",
                            fontSize = 11.sp,
                            color = HighTechCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Vehicle Selector Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = IndustrialAmber
                        )
                    }
                ) {
                    guides.forEachIndexed { index, guide ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    when (guide.typeId) {
                                        "borewell_rig" -> "Borewell Rig"
                                        "excavator" -> "Excavator"
                                        "tipper_truck" -> "Tipper Truck"
                                        else -> "Harvester"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Active Guide Card
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        // Picture
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            Image(
                                painter = painterResource(id = activeGuide.imageResId),
                                contentDescription = activeGuide.vehicleDisplayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                            )
                            Surface(
                                color = Color.Black.copy(alpha = 0.75f),
                                shape = RoundedCornerShape(bottomEnd = 8.dp),
                                modifier = Modifier.align(Alignment.TopStart)
                            ) {
                                Text(
                                    text = activeGuide.vehicleDisplayName,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    item {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "💡 Everyday Purpose:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = IndustrialAmber
                                )
                                Text(
                                    text = activeGuide.plainPurposeHeadline,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "🚜 What to look for:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = HighTechCyan
                                )
                                Text(
                                    text = activeGuide.whatItLooksLike,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    item {
                        Text(
                            text = "Main Structural Parts (Plain English):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    items(activeGuide.structureParts) { part ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = IndustrialAmber.copy(alpha = 0.15f),
                                shape = CircleShape,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("${part.partNumber}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndustrialAmber)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = part.everydayName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(text = part.plainDescription, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSelectVehicleType(activeGuide.typeId)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Show Available ${activeGuide.vehicleDisplayName}s", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
