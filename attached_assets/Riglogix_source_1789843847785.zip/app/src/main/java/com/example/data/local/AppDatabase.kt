package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MachineryEntity::class,
        BookingEntity::class,
        AuctionJobEntity::class,
        AuctionBidEntity::class,
        OwnerFleetEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun machineryDao(): MachineryDao
    abstract fun bookingDao(): BookingDao
    abstract fun auctionDao(): AuctionDao
    abstract fun fleetDao(): FleetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "antigravity_heavy_db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database)
                    }
                }
            }
        }

        suspend fun populateDatabase(database: AppDatabase) {
            val machineryDao = database.machineryDao()
            val bookingDao = database.bookingDao()
            val auctionDao = database.auctionDao()
            val fleetDao = database.fleetDao()

            if (machineryDao.getCount() == 0) {
                machineryDao.insertAll(PrepopulatedData.machineryList)
            }
            if (bookingDao.getCount() == 0) {
                PrepopulatedData.sampleBookings.forEach { bookingDao.insertBooking(it) }
            }
            if (auctionDao.getJobCount() == 0) {
                PrepopulatedData.sampleAuctionJobs.forEach { auctionDao.insertJob(it) }
                PrepopulatedData.sampleBids.forEach { auctionDao.insertBid(it) }
            }
            if (fleetDao.getCount() == 0) {
                fleetDao.insertAllFleet(PrepopulatedData.sampleOwnerFleet)
            }
        }
    }
}
