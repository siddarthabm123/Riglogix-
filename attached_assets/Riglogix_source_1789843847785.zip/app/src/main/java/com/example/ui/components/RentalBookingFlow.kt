package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EditLocation
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MachineryEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen
import java.util.Locale

/**
 * Full Rental Booking Flow Bottom Sheet allowing users to:
 * 1. Select / switch vehicle
 * 2. Specify Date (presets + custom)
 * 3. Specify Time (shift presets + custom)
 * 4. Specify Location (site address + presets + GPS shortcut)
 * 5. Input Work Units with live upfront transparent pricing
 * 6. Submit Rental Request with status 'Pending'
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RentalBookingBottomSheet(
    machinery: MachineryEntity,
    availableVehicles: List<MachineryEntity> = emptyList(),
    onDismiss: () -> Unit,
    onConfirmBooking: (
        selectedMachine: MachineryEntity,
        date: String,
        time: String,
        location: String,
        units: Double
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var currentVehicle by remember { mutableStateOf(machinery) }
    var showVehicleDropdown by remember { mutableStateOf(false) }

    // Date state
    val datePresets = listOf("Today, Sep 19", "Tomorrow, Sep 20", "In 2 Days, Sep 21", "Next Monday")
    var selectedDatePreset by remember { mutableStateOf(datePresets[0]) }
    var customDateInput by remember { mutableStateOf(selectedDatePreset) }

    // Time state
    val timePresets = listOf("07:00 AM (Morning Shift)", "09:00 AM (Day Shift)", "01:00 PM (Afternoon)", "06:00 PM (Night Shift)")
    var selectedTimePreset by remember { mutableStateOf(timePresets[1]) }
    var customTimeInput by remember { mutableStateOf("09:00 AM") }

    // Location state
    var locationInput by remember { mutableStateOf("Green Acres Farm, North Sector Hex #${currentVehicle.h3HexId}") }
    val locationPresets = listOf(
        "Green Acres Farm Sector",
        "Plot 42, Sunrise Industrial Park",
        "Highway Expansion KM 14",
        "East Valley Mango Orchard"
    )

    // Units state
    val defaultUnits = when (currentVehicle.rateUnit) {
        "per ft" -> 750.0
        "per km" -> 150.0
        "per hr" -> 6.0
        else -> 4.0
    }
    var unitsInput by remember { mutableStateOf(defaultUnits.toInt().toString()) }
    val units = unitsInput.toDoubleOrNull() ?: 1.0

    // Price calculation
    val basePrice = currentVehicle.baseRate
    val servicePrice = currentVehicle.ratePerUnit * units
    val fuelSurcharge = currentVehicle.fuelIndexSurcharge
    val subtotal = basePrice + servicePrice + fuelSurcharge
    val antigravityFee = subtotal * 0.035
    val totalCustomerCost = subtotal + antigravityFee
    val savedCommission = (subtotal * 0.30) - antigravityFee

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("rental_booking_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = IndustrialAmber.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Handshake,
                                contentDescription = null,
                                tint = IndustrialAmber,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Initiate Rental Request",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Direct-to-Owner • 0% Broker Cut • 3.5% Platform Fee",
                            style = MaterialTheme.typography.labelSmall,
                            color = SuccessGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Vehicle Selector Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Surface(
                                color = HexagonBlue.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = currentVehicle.category.uppercase(),
                                    color = HexagonBlue,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentVehicle.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Owner: ${currentVehicle.ownerName} (${currentVehicle.ownerPhone})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (availableVehicles.isNotEmpty() && availableVehicles.size > 1) {
                            TextButton(
                                onClick = { showVehicleDropdown = !showVehicleDropdown },
                                modifier = Modifier.testTag("change_vehicle_button")
                            ) {
                                Text("Change", fontSize = 12.sp, color = IndustrialAmber)
                            }
                        }
                    }

                    // Vehicle Dropdown if toggled
                    AnimatedVisibility(visible = showVehicleDropdown) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                        ) {
                            Text("Select Different Vehicle:", style = MaterialTheme.typography.labelSmall)
                            Spacer(modifier = Modifier.height(6.dp))
                            availableVehicles.take(5).forEach { vehicle ->
                                Surface(
                                    color = if (vehicle.id == currentVehicle.id) IndustrialAmber.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (vehicle.id == currentVehicle.id) IndustrialAmber else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clickable {
                                            currentVehicle = vehicle
                                            showVehicleDropdown = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(vehicle.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text("₹${vehicle.ratePerUnit.toInt()} ${vehicle.rateUnit} • ${vehicle.ownerName}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        if (vehicle.id == currentVehicle.id) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = GoldenStarColor, modifier = Modifier.size(14.dp))
                            Text("${currentVehicle.ownerRating} (${currentVehicle.completedJobs} jobs)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "₹${currentVehicle.ratePerUnit.toInt()} ${currentVehicle.rateUnit} + ₹${currentVehicle.baseRate.toInt()} Base",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = HighTechCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. DATE SPECIFICATION
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.CalendarToday, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(16.dp))
                Text("Rental Date", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                datePresets.forEach { preset ->
                    val isSelected = selectedDatePreset == preset
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedDatePreset = preset
                            customDateInput = preset
                        },
                        label = { Text(preset, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndustrialAmber,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = customDateInput,
                onValueChange = { customDateInput = it },
                label = { Text("Selected Date (or enter custom date)") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_date_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. TIME SPECIFICATION
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.AccessTime, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(16.dp))
                Text("Operating Shift / Time", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                timePresets.forEach { preset ->
                    val isSelected = selectedTimePreset == preset
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedTimePreset = preset
                            val timePart = preset.substringBefore(" (")
                            customTimeInput = timePart
                        },
                        label = { Text(preset, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndustrialAmber,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = customTimeInput,
                onValueChange = { customTimeInput = it },
                label = { Text("Starting Time (e.g. 08:30 AM)") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_time_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. LOCATION SPECIFICATION
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(16.dp))
                Text("Job Site / Farm Location", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = locationInput,
                onValueChange = { locationInput = it },
                label = { Text("Specify destination address, farm sector or hex") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.EditLocation, contentDescription = null, modifier = Modifier.size(16.dp)) },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            locationInput = "Current GPS Target Site Hex #${currentVehicle.h3HexId}"
                        }
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = "Use GPS Location", tint = HighTechCyan)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_location_input")
            )

            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(locationPresets) { loc ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.clickable { locationInput = loc }
                    ) {
                        Text(
                            text = loc,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. WORK UNITS SPECIFICATION
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Agriculture, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(16.dp))
                Text(
                    text = when (currentVehicle.rateUnit) {
                        "per ft" -> "Target Borewell Depth"
                        "per km" -> "Haulage Logistics Distance"
                        "per hr" -> "Estimated Operating Hours"
                        else -> "Operating Units (${currentVehicle.rateUnit})"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = unitsInput,
                onValueChange = { unitsInput = it },
                label = { Text("Quantity (${currentVehicle.rateUnit})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_units_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 5. TRANSPARENT PRICING BREAKDOWN CARD
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Upfront Transparent Pricing",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = HighTechCyan
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    BookingPriceRow("Base Mobilization", "₹${basePrice.toInt()}")
                    BookingPriceRow("Work Cost (${units.toInt()} ${currentVehicle.rateUnit})", "₹${servicePrice.toInt()}")
                    BookingPriceRow("Fuel Index Surcharge", "₹${fuelSurcharge.toInt()}")
                    BookingPriceRow("RigLogix Flat Fee (3.5%)", "₹${String.format(Locale("en", "IN"), "%.2f", antigravityFee)}")

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Total Customer Cost",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "₹${String.format(Locale("en", "IN"), "%.2f", totalCustomerCost)}",
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Owner Receives",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${String.format(Locale("en", "IN"), "%.2f", subtotal)} (100% net)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = SuccessGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = SuccessGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Saved ~₹${savedCommission.toInt()} vs traditional 30% broker commission",
                                color = SuccessGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 6. CONFIRM / SUBMIT BUTTON
            Button(
                onClick = {
                    onConfirmBooking(
                        currentVehicle,
                        customDateInput,
                        customTimeInput,
                        locationInput,
                        units
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_rental_request_button")
            ) {
                Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Initiate Rental Request (Status: Pending)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun BookingPriceRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Success Confirmation Dialog shown right after initiating a rental request.
 */
@Composable
fun BookingSuccessConfirmationDialog(
    bookingId: Int,
    machineryTitle: String,
    scheduledDate: String,
    scheduledTime: String,
    jobLocation: String,
    onTrackLive: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AlertDialog(
        modifier = modifier,
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(24.dp))
                Text("Rental Request Initiated!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = IndustrialAmber.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Status: PENDING", color = IndustrialAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Ref #BK-${bookingId}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Text(
                    text = machineryTitle,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Scheduled: $scheduledDate at $scheduledTime\nLocation: $jobLocation",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "The machinery owner has been notified via the IoT telematics hub. You can monitor the live mobilization and on-site operation in real-time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onTrackLive()
                },
                colors = ButtonDefaults.buttonColors(containerColor = HighTechCyan),
                modifier = Modifier.testTag("track_booking_live_confirm_button")
            ) {
                Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Track Live Status")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
