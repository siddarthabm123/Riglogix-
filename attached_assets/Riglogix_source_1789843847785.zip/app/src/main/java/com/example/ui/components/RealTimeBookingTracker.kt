package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookingEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen

/**
 * Stages in a rental booking lifecycle:
 * 1. PENDING: Rental request submitted, awaiting operator mobilization
 * 2. MOBILIZING: Machine in transit, GPS & telematics corridor tracking
 * 3. IN_PROGRESS: On-site work actively executing
 * 4. COMPLETED: Job signed off, escrow released, open for owner review
 */
enum class BookingLifecycleStage(
    val key: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color
) {
    PENDING(
        key = "PENDING",
        title = "Pending",
        description = "Rental request confirmed • Awaiting dispatch",
        icon = Icons.Default.CalendarToday,
        color = IndustrialAmber
    ),
    MOBILIZING(
        key = "MOBILIZING",
        title = "Mobilizing",
        description = "Vehicle in transit • H3 corridor route",
        icon = Icons.Default.LocalShipping,
        color = HexagonBlue
    ),
    IN_PROGRESS(
        key = "IN_PROGRESS",
        title = "In Progress",
        description = "On-site operations active • Live IoT telematics",
        icon = Icons.Default.Engineering,
        color = HighTechCyan
    ),
    COMPLETED(
        key = "COMPLETED",
        title = "Completed",
        description = "Job finished & verified • Escrow settled",
        icon = Icons.Default.CheckCircle,
        color = SuccessGreen
    );

    companion object {
        fun fromStatus(status: String): BookingLifecycleStage {
            return when (status.uppercase()) {
                "PENDING" -> PENDING
                "CONFIRMED" -> PENDING
                "MOBILIZING" -> MOBILIZING
                "ON_SITE" -> IN_PROGRESS
                "IN_PROGRESS" -> IN_PROGRESS
                "COMPLETED" -> COMPLETED
                else -> PENDING
            }
        }
    }
}

/**
 * Real-time Tracking Component that visualizes the current status of a rental booking,
 * such as 'Pending', 'In Progress', or 'Completed', with an interactive milestone stepper,
 * live telematics parameters, and feedback review component upon completion.
 */
@Composable
fun RealTimeBookingTracker(
    booking: BookingEntity,
    onAdvanceMilestone: () -> Unit,
    onSubmitReview: (rating: Int, comment: String, tags: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentStage = BookingLifecycleStage.fromStatus(booking.status)

    // Pulsing animation for active indicator
    val infiniteTransition = rememberInfiniteTransition(label = "trackingPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("real_time_booking_tracker_${booking.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Status & Reference Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Badge
                Surface(
                    color = currentStage.color.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, currentStage.color.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (currentStage != BookingLifecycleStage.COMPLETED) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .scale(pulseScale)
                                    .background(currentStage.color, CircleShape)
                            )
                        } else {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        Text(
                            text = currentStage.title.uppercase(),
                            color = currentStage.color,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Reference number & date
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Ref #BK-${booking.id}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Machinery Title & Site Location
            Text(
                text = booking.machineryTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = IndustrialAmber,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = booking.jobLocation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "Scheduled: ${booking.bookingDate} at ${booking.bookingTime}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Visual Status Stepper / Pipeline Component
            BookingStatusStepper(
                currentStage = currentStage,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Real-Time Telematics Status Strip
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Sensors,
                                contentDescription = null,
                                tint = HighTechCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "LIVE TELEMATICS STREAM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = HighTechCyan
                            )
                        }

                        Surface(
                            color = SuccessGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "OBD-II SYNC",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = booking.telematicsStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Telematics telemetry chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TrackerStatBox(
                            title = "Status",
                            value = currentStage.title,
                            color = currentStage.color,
                            modifier = Modifier.weight(1f)
                        )
                        TrackerStatBox(
                            title = "Speed / RPM",
                            value = when (currentStage) {
                                BookingLifecycleStage.PENDING -> "0 km/h (Standby)"
                                BookingLifecycleStage.MOBILIZING -> "48 km/h Transit"
                                BookingLifecycleStage.IN_PROGRESS -> "1,840 RPM Active"
                                BookingLifecycleStage.COMPLETED -> "Engine Off"
                            },
                            color = HighTechCyan,
                            modifier = Modifier.weight(1.2f)
                        )
                        TrackerStatBox(
                            title = "Telemetry",
                            value = when (currentStage) {
                                BookingLifecycleStage.PENDING -> "Ready"
                                BookingLifecycleStage.MOBILIZING -> "GPS Locked"
                                BookingLifecycleStage.IN_PROGRESS -> "3,200 PSI"
                                BookingLifecycleStage.COMPLETED -> "Job Logged"
                            },
                            color = IndustrialAmber,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Operator Contact & Pricing Summary Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Operator: ${booking.ownerName}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Total: ₹${booking.totalCustomerCost.toInt()} (${booking.jobUnits.toInt()} ${booking.unitName})",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Call Operator Button
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${booking.ownerPhone}")
                            }
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("call_operator_button_${booking.id}")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call", fontSize = 11.sp)
                    }

                    // Advance Status / Next Milestone Action Button
                    if (currentStage != BookingLifecycleStage.COMPLETED) {
                        Button(
                            onClick = onAdvanceMilestone,
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("advance_status_button_${booking.id}")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (currentStage) {
                                    BookingLifecycleStage.PENDING -> "Dispatch (Mobilize)"
                                    BookingLifecycleStage.MOBILIZING -> "Start Work"
                                    BookingLifecycleStage.IN_PROGRESS -> "Complete Job"
                                    BookingLifecycleStage.COMPLETED -> "Completed"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Star Rating & Feedback Component (Displayed when status is Completed)
            if (currentStage == BookingLifecycleStage.COMPLETED) {
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(14.dp))

                OwnerReviewComponent(
                    booking = booking,
                    onSubmitReview = onSubmitReview
                )
            }
        }
    }
}

@Composable
fun TrackerStatBox(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text(text = title, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
    }
}

/**
 * Visual Status Stepper showing the 4 milestones:
 * [1. Pending] -----> [2. Mobilizing] -----> [3. In Progress] -----> [4. Completed]
 */
@Composable
fun BookingStatusStepper(
    currentStage: BookingLifecycleStage,
    modifier: Modifier = Modifier
) {
    val stages = BookingLifecycleStage.values()
    val currentIndex = stages.indexOf(currentStage)

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            stages.forEachIndexed { index, stage ->
                val isCompleted = index < currentIndex || (currentStage == BookingLifecycleStage.COMPLETED && index == stages.size - 1)
                val isCurrent = index == currentIndex && currentStage != BookingLifecycleStage.COMPLETED

                val stepColor = when {
                    isCompleted -> SuccessGreen
                    isCurrent -> stage.color
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                }

                // Step Icon / Circle
                Surface(
                    shape = CircleShape,
                    color = when {
                        isCompleted -> SuccessGreen
                        isCurrent -> stage.color.copy(alpha = 0.2f)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isCurrent) 2.dp else 1.dp,
                        color = stepColor
                    ),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isCompleted) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        } else {
                            Icon(
                                imageVector = stage.icon,
                                contentDescription = null,
                                tint = if (isCurrent) stage.color else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                // Connecting Line between steps
                if (index < stages.size - 1) {
                    val linePassed = index < currentIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(2.dp)
                            .background(
                                if (linePassed) SuccessGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Step Labels Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            stages.forEachIndexed { index, stage ->
                val isCurrent = index == currentIndex
                val isCompleted = index < currentIndex
                Text(
                    text = stage.title,
                    fontSize = 10.sp,
                    fontWeight = if (isCurrent) FontWeight.Black else if (isCompleted) FontWeight.SemiBold else FontWeight.Normal,
                    color = when {
                        isCurrent -> stage.color
                        isCompleted -> SuccessGreen
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }
    }
}
