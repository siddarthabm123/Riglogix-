package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AuctionBidEntity
import com.example.data.local.AuctionJobEntity
import com.example.ui.theme.HexagonBlue
import com.example.ui.theme.HighTechCyan
import com.example.ui.theme.IndustrialAmber
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AntigravityViewModel
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReverseAuctionScreen(
    viewModel: AntigravityViewModel,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
    isWideScreen: Boolean = false
) {
    val auctionJobs by viewModel.auctionJobs.collectAsStateWithLifecycle()
    val selectedJobId by viewModel.selectedJobId.collectAsStateWithLifecycle()
    val selectedJobBids by viewModel.selectedJobBids.collectAsStateWithLifecycle()

    var showCreateBroadcastDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val selectedJob = auctionJobs.find { it.id == selectedJobId } ?: auctionJobs.firstOrNull()

    if (isWideScreen) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Pane: Active Broadcasts & Broadcast Action
            LazyColumn(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // Explanatory Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = HighTechCyan,
                                    shape = CircleShape,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.TrendingDown,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Smart Reverse Auction Engine",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Non-urgent job? Broadcast to nearby equipment owners within your H3 geofence. Operators bid downward to secure the job, guaranteeing you the absolute lowest market rate without broker markups.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = { showCreateBroadcastDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("create_broadcast_button_wide")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Broadcast New Heavy Utility Job", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Active Job Broadcasts (${auctionJobs.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(auctionJobs, key = { it.id }) { job ->
                    val isSelected = job.id == selectedJob?.id
                    AuctionJobCard(
                        job = job,
                        isSelected = isSelected,
                        onClick = { viewModel.selectJob(job.id) }
                    )
                }
            }

            // Right Pane: Live Bidding War Floor for Selected Job
            LazyColumn(
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (selectedJob != null) {
                    val job = selectedJob
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Live Bidding Floor: ${job.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${selectedJobBids.size} operator bids received • Direct contracts",
                                    fontSize = 11.sp,
                                    color = HighTechCyan
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val nextBidAmount = (job.currentLowestBid - 150.0).coerceAtLeast(100.0)
                                    val simulatedNames = listOf("Kavita Heavy Haulers", "Deccan Borewell Fleet", "Apex CAT Operators", "Hindustan Logistics")
                                    val opName = simulatedNames.random()
                                    viewModel.submitDownwardBid(
                                        jobId = job.id,
                                        operatorName = opName,
                                        operatorPhone = "+91 98451 22891",
                                        operatorRating = 4.88,
                                        equipmentTitle = "Verified Heavy Rig (H3 Matched)",
                                        bidAmount = nextBidAmount,
                                        etaMinutes = (20..50).random(),
                                        h3DistanceKm = (5..18).random().toDouble()
                                    ) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Downward bid received: $opName placed ₹${nextBidAmount.toInt()}!")
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("simulate_bid_button_wide")
                            ) {
                                Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = HighTechCyan, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Simulate Bid", fontSize = 11.sp)
                            }
                        }
                    }

                    if (selectedJobBids.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Broadcasting to nearby verified operators... Bids will appear here in real-time.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        items(selectedJobBids, key = { it.id }) { bid ->
                            BidCard(
                                bid = bid,
                                isLowest = bid.bidAmount == job.currentLowestBid,
                                onAccept = {
                                    viewModel.acceptBid(job.id, bid) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Winning bid accepted! Contract locked directly with ${bid.operatorName}.")
                                        }
                                    }
                                }
                            )
                        }
                    }
                } else {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Select a broadcast on the left to inspect real-time operator bidding.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    } else {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("reverse_auction_list"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Explanatory Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = HighTechCyan,
                            shape = CircleShape,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Text(
                            text = "Smart Reverse Auction Engine",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Non-urgent job? Broadcast to nearby equipment owners within your H3 geofence. Operators bid downward to secure the job, guaranteeing you the absolute lowest market rate without broker markups.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { showCreateBroadcastDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("create_broadcast_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Broadcast New Heavy Utility Job", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section Title: Open Broadcasts
        item {
            Text(
                text = "Active Job Broadcasts (${auctionJobs.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Job Broadcast Cards
        items(auctionJobs, key = { it.id }) { job ->
            val isSelected = job.id == selectedJob?.id
            AuctionJobCard(
                job = job,
                isSelected = isSelected,
                onClick = { viewModel.selectJob(job.id) }
            )
        }

        // Live Bids Board for Selected Job
        selectedJob?.let { job ->
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Live Bidding Floor",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Showing live downward bids for Job #${job.id}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Button to simulate an incoming operator bid
                    OutlinedButton(
                        onClick = {
                            val nextBidAmount = (job.currentLowestBid - 150.0).coerceAtLeast(100.0)
                            val simulatedNames = listOf("Kavita Heavy Haulers", "Deccan Borewell Fleet", "Apex CAT Operators", "Hindustan Logistics")
                            val opName = simulatedNames.random()
                            viewModel.submitDownwardBid(
                                jobId = job.id,
                                operatorName = opName,
                                operatorPhone = "+1 (555) 778-${(1000..9999).random()}",
                                operatorRating = 4.88,
                                equipmentTitle = "Verified Heavy Rig (H3 Matched)",
                                bidAmount = nextBidAmount,
                                etaMinutes = (20..50).random(),
                                h3DistanceKm = (5..18).random().toDouble()
                            ) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Downward bid received: $opName placed $$nextBidAmount!")
                                }
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("simulate_bid_button")
                    ) {
                        Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = HighTechCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simulate Bid", fontSize = 11.sp)
                    }
                }
            }

            if (selectedJobBids.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Broadcasting to nearby verified operators... Bids will appear here in real-time.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(selectedJobBids, key = { it.id }) { bid ->
                    BidCard(
                        bid = bid,
                        isLowest = bid.bidAmount == job.currentLowestBid,
                        onAccept = {
                            viewModel.acceptBid(job.id, bid) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Winning bid accepted! Contract locked directly with ${bid.operatorName}.")
                                }
                            }
                        }
                    )
                }
            }
        }
    }
    }

    // Create Auction Dialog
    if (showCreateBroadcastDialog) {
        CreateBroadcastDialog(
            onDismiss = { showCreateBroadcastDialog = false },
            onConfirm = { title, category, location, details, ceilingPrice ->
                viewModel.createAuctionJob(
                    title = title,
                    category = category,
                    location = location,
                    details = details,
                    ceilingPrice = ceilingPrice
                ) {
                    showCreateBroadcastDialog = false
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Broadcast active! Nearby operators are being notified.")
                    }
                }
            }
        )
    }
}

@Composable
fun AuctionJobCard(
    job: AuctionJobEntity,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalSaved = job.ceilingPrice - job.currentLowestBid

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("auction_job_card_${job.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected) {
            CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(IndustrialAmber))
        } else {
            CardDefaults.outlinedCardBorder()
        }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (job.category) {
                        "Agriculture" -> SuccessGreen.copy(alpha = 0.15f)
                        "Construction" -> IndustrialAmber.copy(alpha = 0.15f)
                        else -> HexagonBlue.copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = job.category.uppercase(),
                        color = when (job.category) {
                            "Agriculture" -> SuccessGreen
                            "Construction" -> IndustrialAmber
                            else -> HexagonBlue
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.Schedule,
                        contentDescription = null,
                        tint = HighTechCyan,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "${job.expiresAtMinutes}m left",
                        fontSize = 11.sp,
                        color = HighTechCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = job.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = job.location,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(10.dp))

            // Pricing comparison: Starting ceiling vs current lowest bid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Ceiling Target: ₹${job.ceilingPrice.toInt()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Lowest Bid: ₹${job.currentLowestBid.toInt()}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = HighTechCyan
                        )
                        Icon(
                            Icons.Default.TrendingDown,
                            contentDescription = null,
                            tint = HighTechCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Surface(
                    color = SuccessGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "Save ₹${totalSaved.toInt()} (${job.bidCount} bids)",
                        color = SuccessGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BidCard(
    bid: AuctionBidEntity,
    isLowest: Boolean,
    onAccept: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("bid_card_${bid.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isLowest) HighTechCyan else MaterialTheme.colorScheme.outline
            )
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = bid.operatorName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Verified KYC",
                            tint = SuccessGreen,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Text(
                        text = bid.equipmentTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "₹${bid.bidAmount.toInt()}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = if (isLowest) HighTechCyan else MaterialTheme.colorScheme.onSurface
                    )
                    if (isLowest) {
                        Surface(
                            color = HighTechCyan.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "LOWEST RATE",
                                color = HighTechCyan,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = IndustrialAmber, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("${bid.operatorRating}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text("•", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("ETA ${bid.etaMinutes} mins", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("•", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${bid.h3DistanceKm.toInt()} km", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("accept_bid_button_${bid.id}")
                ) {
                    Text("Accept Bid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateBroadcastDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, category: String, location: String, details: String, ceilingPrice: Double) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Agriculture") }
    var location by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var ceilingPriceInput by remember { mutableStateOf("") }

    val categories = listOf("Agriculture", "Construction", "Logistics")
    var categoryExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Broadcast Heavy Utility Job",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Job Title (e.g. 1000ft Borewell or 20T Lorry)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category Dropdown
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Work Site / Transit Route (H3 Indexed)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("Machinery Requirements & Depth/Tonnage") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ceilingPriceInput,
                    onValueChange = { ceilingPriceInput = it },
                    label = { Text("Ceiling Target Budget (₹ INR)") },
                    placeholder = { Text("e.g. 95000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val ceiling = ceilingPriceInput.toDoubleOrNull() ?: 50000.0
                    val finalTitle = if (title.isBlank()) "Heavy Utility Job Broadcast" else title
                    val finalLocation = if (location.isBlank()) "North Sector Hex #8828308281ff" else location
                    val finalDetails = if (details.isBlank()) "Verified equipment needed with operator." else details
                    onConfirm(finalTitle, selectedCategory, finalLocation, finalDetails, ceiling)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndustrialAmber),
                modifier = Modifier.testTag("submit_broadcast_dialog_button")
            ) {
                Text("Broadcast to Owners")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
