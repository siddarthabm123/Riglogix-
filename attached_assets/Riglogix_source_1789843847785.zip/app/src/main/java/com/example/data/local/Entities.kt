package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "machinery")
data class MachineryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // "Agriculture", "Construction", "Logistics"
    val subCategory: String,
    val specs: String,
    val ownerName: String,
    val ownerPhone: String,
    val ownerRating: Double,
    val completedJobs: Int,
    val baseRate: Double,
    val ratePerUnit: Double,
    val rateUnit: String, // "per ft", "per hr", "per km", "per day"
    val fuelIndexSurcharge: Double,
    val distanceKm: Double,
    val h3HexId: String,
    val roadClassification: String,
    val isKycVerified: Boolean = true,
    val hasTelematicsGps: Boolean = true,
    val isAvailable: Boolean = true
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val machineryId: Int,
    val machineryTitle: String,
    val category: String,
    val ownerName: String,
    val ownerPhone: String,
    val bookingDate: String,
    val bookingTime: String = "08:00 AM",
    val jobLocation: String,
    val jobUnits: Double,
    val unitName: String,
    val basePrice: Double,
    val servicePrice: Double,
    val fuelSurcharge: Double,
    val antigravityFee: Double, // 3.5%
    val totalCustomerCost: Double,
    val ownerNetEarnings: Double,
    val status: String, // "PENDING", "MOBILIZING", "IN_PROGRESS", "COMPLETED"
    val telematicsStatus: String,
    val timestamp: Long = System.currentTimeMillis(),
    val rating: Int? = null,
    val reviewComment: String? = null,
    val reviewTags: String? = null,
    val reviewedAt: Long? = null
)

@Entity(tableName = "auction_jobs")
data class AuctionJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val location: String,
    val details: String,
    val ceilingPrice: Double,
    val currentLowestBid: Double,
    val bidCount: Int,
    val status: String, // "ACTIVE_BIDDING", "AWARDED", "COMPLETED"
    val expiresAtMinutes: Int = 18,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "auction_bids")
data class AuctionBidEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val jobId: Int,
    val operatorName: String,
    val operatorPhone: String,
    val operatorRating: Double,
    val equipmentTitle: String,
    val bidAmount: Double,
    val etaMinutes: Int,
    val h3DistanceKm: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val isAccepted: Boolean = false
)

@Entity(tableName = "owner_fleet")
data class OwnerFleetEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val regNumber: String,
    val capacity: String,
    val hourlyOrKmRate: Double,
    val rateUnit: String,
    val isOnline: Boolean = true,
    val currentJob: String? = null,
    val fuelLevelPercent: Int = 88,
    val engineHours: Int = 1420,
    val telematicsIotId: String = "OBD2-ANTIGRAV-901"
)
